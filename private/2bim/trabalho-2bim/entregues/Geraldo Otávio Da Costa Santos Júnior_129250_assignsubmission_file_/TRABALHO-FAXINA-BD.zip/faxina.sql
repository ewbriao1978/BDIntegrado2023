DROP DATABASE IF EXISTS faxina;
CREATE DATABASE faxina;

\c faxina;

CREATE TABLE diarista (
	id integer PRIMARY KEY,
	cpf char(11) not null unique,
	nome text not null
);

CREATE TABLE responsavel (
	id integer PRIMARY KEY,
	cpf char(11) not null unique,
	nome text not null
);

CREATE TABLE tamanho (
	id integer PRIMARY KEY,
	nome text check ((nome = 'pequena') OR (nome = 'media') OR (nome = 'grande')),
	valor real 
);

CREATE TABLE residencia (
	id integer PRIMARY KEY,
	cidade text not null,
	bairro text not null,
	rua text not null,
	complemento text,
	numero text not null,
	tamanho_id integer references tamanho(id),
	responsavel_id integer references responsavel(id)
);

CREATE TABLE faxina (
	id integer PRIMARY KEY,
	data DATE , --verificação só com trigger after insert
	presenca BOOLEAN,
	feedback text,
	dano real, -- check(CASE when presenca is FALSE THEN dano = 0 else presenca is true end),
	gorjeta real,-- check(CASE when presenca is FALSE THEN dano = 0 else presenca is true end),
	diarista_id integer references diarista(id),
	residencia_id integer references residencia(id)
);

CREATE TABLE AUDITORIA(
	id serial, 
	nome_diarista text, 
	id_dia integer
);

INSERT INTO diarista ( id, nome, cpf ) VALUES (1, 'Lurdes', '00000000000'); 
INSERT INTO diarista ( id, nome, cpf ) VALUES (2, 'Jurema', '11111111111');
INSERT INTO diarista ( id, nome, cpf ) VALUES (3, 'Vigora', '22222222222');

INSERT INTO responsavel (id, nome, cpf ) VALUES (1,'Brigite', '33333333333' );
INSERT INTO responsavel (id, nome, cpf ) VALUES (2,'Crigite', '44444444444' );
INSERT INTO responsavel (id, nome, cpf ) VALUES (3,'Drigite', '55555555555' );

INSERT INTO tamanho (id, nome, valor ) VALUES (1, 'pequena', 50); 
INSERT INTO tamanho (id, nome, valor ) VALUES (2, 'media', 100);
INSERT INTO tamanho (id, nome, valor ) VALUES (3, 'grande', 150);

INSERT INTO residencia (id, cidade, bairro, rua, complemento, numero, tamanho_id, responsavel_id) VALUES (1, 'Rio Grande', 'Lar gaucho', 'Luther', 'casa', '243', 1, 1);
INSERT INTO residencia (id, cidade, bairro, rua, complemento, numero, tamanho_id, responsavel_id) VALUES (2, 'Rio', 'Lar', 'Clark', 'ap', '243', 2, 2);
INSERT INTO residencia (id, cidade, bairro, rua, complemento, numero, tamanho_id, responsavel_id) VALUES (3, 'Grande', 'Gaucho', 'Lois', 'sb', '324', 3, 3);

INSERT INTO faxina (id, data, presenca, feedback, gorjeta, dano, diarista_id, residencia_id) VALUES (1, '2022-06-01', 'true', 'Boa limpeza', 10, 20, 1, 1); 
INSERT INTO faxina (id, data, presenca, feedback, gorjeta, dano, diarista_id, residencia_id) VALUES(2, '2022-06-02', 'true', 'Poderia ser melhor', 30, 40, 2, 2); 
INSERT INTO faxina (id, data, presenca, feedback, gorjeta, dano, diarista_id, residencia_id) VALUES(5, '2022-05-17', 'false', 'Nem apareceu',0, 0, 2, 1);
INSERT INTO faxina (id, data, presenca, feedback, gorjeta, dano, diarista_id, residencia_id) VALUES(3, '2022-02-15', 'true', 'Muito rápida e boa, adorei!', 60, 70, 3, 3);

CREATE OR REPLACE FUNCTION presencas(id_dia INTEGER) RETURNS text AS 
$$
DECLARE
	presencas real;
	--faltas real;
	faxinas real;
	nome_diarista TEXT;
	id_dia ALIAS FOR $1;
	percentagem real;
BEGIN
	SELECT INTO faxinas count(faxina.presenca) FROM faxina WHERE presenca is not null AND diarista_id = $1 GROUP BY diarista_id;
	SELECT INTO presencas count(faxina.presenca) FROM faxina WHERE presenca IS true AND diarista_id = $1 GROUP BY diarista_id;
	SELECT INTO nome_diarista nome FROM diarista WHERE diarista.id = $1;
	--Abaixo poderia ser usado para calcular as faltas mas não houve necessidade;
	--SELECT INTO faltas count(faxina.presenca) FROM faxina WHERE presenca IS NOT true AND diarista_id = $1 GROUP BY diarista_id;
	percentagem := (presencas/faxinas)*100;	
	RETURN 'Nome = '||nome_diarista|| '  ' ||'Quantidade de faxinas = '||faxinas ||'  '||'Presenças em = '||' '||percentagem || '%';
END;
$$ LANGUAGE 'plpgsql';

CREATE OR REPLACE FUNCTION valor_final(id_dia INTEGER) RETURNS text AS 
$$
DECLARE
	id_dia ALIAS FOR $1;
	gorjetas real;
	danos real;
	valores real;
	nome_diarista TEXT;
	total real; 
BEGIN
	SELECT INTO gorjetas sum(faxina.gorjeta) FROM faxina WHERE diarista_id = $1 GROUP BY diarista_id;
	SELECT INTO danos sum(faxina.dano) FROM faxina WHERE presenca IS true AND diarista_id = $1 GROUP BY diarista_id;
	SELECT INTO valores sum(tamanho.valor) FROM tamanho natural join faxina where presenca is true AND diarista_id = $1;
	SELECT INTO nome_diarista nome FROM diarista WHERE diarista.id = $1;
	
	total := (valores + gorjetas) - danos;	
    RETURN 'Nome = '||nome_diarista|| '  ' ||'Recebeu Valor Final = '||total;
END;
$$ LANGUAGE 'plpgsql';

--PRECISO DE AJUDA PARA ENTENDER
/*CREATE OR REPLACE FUNCTION excluir(id_dia integer) RETURNS TEXT AS 
$$
DECLARE
	presencas real;
	faxinas real;
	nome_diarista TEXT;
	id_dia alias for $1;
	percentagem real;
BEGIN
	--id_dia := NEW.diarista_id;
	SELECT INTO faxinas count(faxina.presenca) FROM faxina WHERE diarista_id = $1 GROUP BY diarista_id;
	SELECT INTO presencas count(faxina.presenca) FROM faxina WHERE presenca IS true AND diarista_id = $1 GROUP BY diarista_id;
	SELECT INTO nome_diarista nome FROM diarista WHERE diarista.id = $1;

	percentagem := (presencas/faxinas)*100;
	IF  percentagem < 75.00 THEN
		INSERT INTO AUDITORIA(nome_diarista, id_dia) values (nome_diarista, $1);
		DELETE FROM faxina WHERE diarista_id = $1;
		DELETE FROM diarista WHERE id = $1;
	END IF;
	
	RETURN 'Exclui certinho';
END;
$$ LANGUAGE 'plpgsql';

CREATE OR REPLACE TRIGGER excluir AFTER INSERT ON FAXINA
FOR EACH ROW EXECUTE PROCEDURE excluir();*/

CREATE OR REPLACE FUNCTION agendar(id INTEGER, diarista INTEGER, residencia INTEGER,  date, periodo INTEGER) RETURNS text AS 
$$
DECLARE
	id ALIAS FOR $1;
    diarista ALIAS FOR $2;
	residencia ALIAS FOR $3;
	date alias for $4;
	periodo ALIAS FOR $5;
		
BEGIN
	case when $5 = 15 THEN INSERT INTO faxina (id,diarista_id, residencia_id, data) VALUES ($1, $2, $3, $4);
		 when $5 = 30 THEN INSERT INTO faxina (id,diarista_id, residencia_id, data) VALUES ($1, $2, $3, $4);

	ELSE
		RAISE EXCEPTION 'Apenas podem ser agendados periodos de 15 ou 30 dias.';
	END CASE;
	RETURN 'Faxina agendada para o dia = ' || $4 || ',  com a diarista = ' || $2;
END;
$$ LANGUAGE 'plpgsql';


--select agendar(1, 1, 1, '01-02-2023', 15);



CREATE OR REPLACE FUNCTION excluir() RETURNS TRIGGER AS 
$$
DECLARE
	presencas real;
	faxinas real;
	nome_diarista TEXT;
	id_dia integer;
	percentagem real;
BEGIN
	id_dia := NEW.diarista_id;
	SELECT INTO faxinas count(faxina.presenca) FROM faxina WHERE diarista_id = id_dia GROUP BY diarista_id;
	SELECT INTO presencas count(faxina.presenca) FROM faxina WHERE presenca IS true AND diarista_id = id_dia GROUP BY diarista_id;
	SELECT INTO nome_diarista nome FROM diarista WHERE diarista.id = id_dia;

	percentagem := (presencas/faxinas)*100;
	IF  percentagem < 75.00 THEN
		INSERT INTO AUDITORIA(nome_diarista, id_dia) values (nome_diarista, id_dia);
		DELETE FROM faxina WHERE diarista_id = id_dia;
		DELETE FROM diarista WHERE id = id_dia;
	END IF;
	
	RETURN NEW;
END;
$$ LANGUAGE 'plpgsql';

CREATE TRIGGER tg_excluir AFTER INSERT ON FAXINA
FOR EACH ROW EXECUTE PROCEDURE excluir();



