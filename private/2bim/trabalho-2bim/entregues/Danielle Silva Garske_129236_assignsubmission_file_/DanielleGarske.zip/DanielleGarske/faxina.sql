DROP DATABASE IF EXISTS faxina;
CREATE DATABASE faxina;

\c faxina

CREATE TABLE diarista(
    id  serial primary key,
    nome character (80),
    cpf character(14) unique
);

CREATE TABLE tamanho(
  id serial primary key,
  valor real,
  descricao text
);

CREATE TABLE responsavel(
    id serial primary key,
    nome character (80),
    cpf character(14) unique
);

CREATE TABLE residencia(
    id serial primary key,
    rua character(100),
    numero int,
    complemento character(50),
    bairro character(50),
    cidade character(50),
    tamanho_id integer REFERENCES tamanho(id),
    responsavel_id integer REFERENCES responsavel(id)
);

CREATE TABLE faxina(
    id serial primary key,
    data date,
    valor_inicial real,
    valor_final real,
    realizada boolean,
   adicional_desconto text,
    feedback text,
    diarista_id integer not null REFERENCES diarista(id),
    residencia_id integer not null REFERENCES residencia (id)
);

INSERT INTO diarista(cpf,nome) VALUES ('767.156.960-71','Maya Carolina Vieira');
INSERT INTO diarista(cpf,nome) VALUES ('190.489.020-29','Simone Sônia Assunção ');
INSERT INTO diarista(cpf,nome) VALUES ('805.847.960-80','Mariah Helena Heloisa da Mata');
INSERT INTO diarista(cpf,nome) VALUES ('932.467.460-95','Helena Manuela Sara Almeida');
INSERT INTO diarista(cpf,nome) VALUES ('330.925.520-40','Emilly Aparecida  Moura');
INSERT INTO diarista(cpf,nome) VALUES ('034.943.930-36','Isabelle Cristiane Assis');
INSERT INTO diarista(cpf,nome) VALUES ('700.931.290-76','Eliane Marli Fernandes');
INSERT INTO diarista(cpf,nome) VALUES ('015.758.170-55','Beatriz  Galvão');
INSERT INTO diarista(cpf,nome) VALUES ('580.576.740-67','Camila Caroline Santos');
INSERT INTO diarista(cpf,nome) VALUES ('181.676.070-62','Sônia Porto');

INSERT INTO tamanho(descricao,valor) VALUES ('residência pequena valor a partir de :',75.00);
INSERT INTO tamanho(descricao,valor) VALUES ('residência média a partir de :',125.00);
INSERT INTO tamanho(descricao,valor) VALUES ('residência grande a partir de :',200.00);
INSERT INTO tamanho(descricao,valor) VALUES ('sobrados a partir de :',250.00);

INSERT INTO responsavel(cpf,nome) VALUES ('560.870.400-21','Valentina Ramos');
INSERT INTO responsavel(cpf,nome) VALUES ('845.236.600-00','Isabella Monteiro');
INSERT INTO responsavel(cpf,nome) VALUES ('671.542.040-87','Teresinha Baptista');
INSERT INTO responsavel(cpf,nome) VALUES ('688.953.980-09','Alice das Neves');
INSERT INTO responsavel(cpf,nome) VALUES ('001.246.310-88','Amanda Porto');
INSERT INTO responsavel(cpf,nome) VALUES ('914.476.130-90','Vera Martins');

INSERT INTO residencia(cidade,bairro,rua,numero,complemento,tamanho_id, responsavel_id) VALUES ('Rio Grande','Vila Rural', 'Rua Rio Amazonas',124,'casa B',1,1);
INSERT INTO residencia(cidade,bairro,rua,numero,complemento,tamanho_id, responsavel_id) VALUES ('Rio Grande','Humaitá', 'Ângelo Trindade',1611,'apto 301',2,2);
INSERT INTO residencia(cidade,bairro,rua,numero,complemento,tamanho_id, responsavel_id) VALUES ('Rio Grande','Cassino', 'Dom Pedrito',481,'casa 3',1,3);
INSERT INTO residencia(cidade,bairro,rua,numero,complemento,tamanho_id, responsavel_id) VALUES ('Rio Grande','Cassino', 'Júlio de Castilhos',109,'Ap 401',3,4);
INSERT INTO residencia(cidade,bairro,rua,numero,complemento,tamanho_id, responsavel_id) VALUES ('Rio Grande','Bolaxa', 'Ana Pernigotti',200,'casa 10',4,5);
INSERT INTO residencia(cidade,bairro,rua,numero,complemento,tamanho_id, responsavel_id) VALUES ('Rio Grande','Santa Rita de Cássia', 'Rua Doze',509,'casa fundos',4,6);

INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-06-01',75,100,'true','Valor adicional de R$25,00 devido a qualidade do serviço','Ótimo serviço',4,1);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-04-30',125,160,'true','Valor adicional de R$35,00 devido a ter limpado forros e armários','Responsável e simpátca',3,2);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-06-27',200,250,'true','Valor adicional R$ 50 devido ter chegado antes do combinado e efetuar serviços que não haviam sido combinados inicialmente','Funcionária exemplar.',3,3);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-06-28',200,150,'true','Descontado R$50 devido ter quebrado conjunto de copos','Limpeza ok, porém precisa prestar mais atenção ao manusear os utencílios',2,4);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-05-25',125,0,'false','Deixou a desejar,a profissional não compareceu ao local como combinado','',1,5);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-06-28',200,225,'true','Valor adicional de R$25,00 pois auxiliou na arrumação do roupeiro','Recomendo',5,6);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-04-04',125,125,'true','','Boa profissional.',3,5);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-04-25',250,300,'true','Valor adicional de R$50,00 devido a agilidade','Ótimo serviço, funcionária muito ágil.',1,2);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-04-25',250,300,'true','Valor adicional de R$50,00 devido a agilidade','Ótimo serviço, funcionária muito ágil.',3,2);
INSERT INTO faxina(data, valor_inicial,valor_final,realizada,acrescimo_desconto,feedback,diarista_id,residencia_id) VALUES('2022-04-25',250,0,'false','faltou','Atestado de Covid',5,2);
