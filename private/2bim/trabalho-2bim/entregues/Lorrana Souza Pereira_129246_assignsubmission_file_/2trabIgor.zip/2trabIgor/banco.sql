-- O B.D deve controlar o histórico de faxinas 
-- realizados por cada diarista em cada residência.

-- Cada Diarista possui um identificador (id), cpf e nome;
DROP DATABASE IF EXISTS dptfaxina;
CREATE DATABASE dptfaxina;

\c dptfaxina;

DROP TABLE IF EXISTS diarista;
DROP TABLE IF EXISTS faxina;
DROP TABLE IF EXISTS tamanho;
DROP TABLE IF EXISTS residencia;
DROP TABLE IF EXISTS responsavel;


CREATE TABLE diarista(
    id SERIAL primary key,
    nome VARCHAR(100) NOT NULL,
    CPF VARCHAR(11) NOT NULL,
    CONSTRAINT CPF_Diarista_UNIQUE UNIQUE (CPF)

);

CREATE TABLE responsavel (
    id SERIAL primary key,
    nome VARCHAR(100) NOT NULL,
    CPF VARCHAR(11),
    CONSTRAINT CPF_Responsavel_UNIQUE UNIQUE (CPF)

);

CREATE TABLE tamanho (
    id SERIAL primary key,
    descricao text,
    valor real
);

CREATE TABLE residencia (
    id SERIAL primary key,
    id_responsavel integer NOT NULL,
    id_tamanho INTEGER NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    rua VARCHAR(50) NOT NULL,
    complemento VARCHAR(30),
    numero VARCHAR(8),
    CONSTRAINT FK_responsavel FOREIGN KEY (id_responsavel)
      		REFERENCES  responsavel (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT FK_tamanho FOREIGN KEY (id_tamanho)
      		REFERENCES  tamanho (id) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE faxina (
    id serial PRIMARY KEY,
    id_residencia integer,
    id_diarista integer,
    presenca boolean,
    valor REAL NOT NULL,
    valor_pago REAL,
    feedback varchar(100),
    data timestamp NOT NULL,
    CONSTRAINT FK_Faxina_residencia FOREIGN KEY (id_residencia)
        REFERENCES  residencia (id) ON DELETE  NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_Faxina_diarista FOREIGN KEY (id_diarista)
        REFERENCES diarista (id) ON DELETE NO ACTION ON UPDATE CASCADE
);
-- select id_tamanho from faxina f 
-- inner join residencia r r.id_residencia =  
-- id_residencia = 1;
-- CREATE TABLE DiaristaResidencia (
--     id_responsavel integer,
--     id_residencia integer,
--     valor REAL,
--     feedback varchar(100),
--     faltou boolean NOT NULL,
--     primary key (id_responsavel,id_residencia),
--     CONSTRAINT FK_DR_responsavel FOREIGN KEY (id_responsavel)
--         REFERENCES  responsavel (id) ON DELETE NO ACTION ON UPDATE CASCADE,
--     CONSTRAINT FK_DR_residencia FOREIGN KEY (id_residencia)
--         REFERENCES  residencia (id) ON DELETE NO ACTION ON UPDATE CASCADE
-- );

INSERT INTO diarista (nome, cpf) VALUES ('Bruna Cunha',03791585450);
INSERT INTO diarista (nome, cpf) VALUES ('Paulo Fernandes',98678910000);
INSERT INTO diarista (nome, cpf) VALUES ('Andressa Pereira Ferreira',98645810088);
INSERT INTO responsavel (nome, cpf) VALUES ('Carlos Ferreira',08645810088);
INSERT INTO responsavel (nome, cpf) VALUES ('Ana da Silva',07645810088);
INSERT INTO responsavel (nome, cpf) VALUES ('Angela Pirheiro',09845810008);
INSERT INTO tamanho (descricao, valor) VALUES ('pequena', 200);
INSERT INTO tamanho (descricao, valor) VALUES ('média', 300);
INSERT INTO tamanho (descricao, valor) VALUES ('grande', 400);

INSERT INTO residencia (id_responsavel, id_tamanho, cidade, bairro, 
rua, numero) VALUES (1, 1,'Rio Grande', 'São João', 
'Roberto Socowisky', '338');
INSERT INTO residencia (id_responsavel,id_tamanho, cidade, bairro, 
rua, numero) VALUES (2,2,'Rio Grande', 
'São Miguel', 'General Boehm', '400');
INSERT INTO residencia (id_responsavel, id_tamanho, cidade, bairro, 
rua, numero) VALUES (3, 3,'Pelotas', 'Navagantes', 'Major Carlos pinto', '120');


-- -- Crie um STORE PROCEDURE que permita agendar quinzenalmente ou mensalmente faxinas em uma determinada residência:
-- -- A diarista e a residência devem ser considerados parâmetros de entrada
-- --   INSERT INTO faxina (id_residencia, id_diarista,data) VALUES ($1,$2, CURRENT_DATE);
-- -- select agenda(1,1,'uuuu');
-- CURRENT_DATE - cast((cast(extract(day from current_date) as text) || ' days')  as interval) + cast ('1 day' as interval) + cast ('1 month' as interval);
-- select cast((cast(extract(day from current_date) as text) || ' days')  as interval);

CREATE OR REPLACE FUNCTION agenda(integer, integer, text) RETURNS void AS
$$
DECLARE
i INT;
intervalo int;
cont int;
valor_real_tamanho real;
cont_dias int;
text_interval text;
cod_diarista ALIAS FOR $1;
cod_residencia ALIAS FOR $2;
valor ALIAS FOR $3;

BEGIN
 i := 0;
 intervalo := 0;
 cont_dias := 1;
 IF valor in ('Mensalmente') THEN
    while 
        extract(year from (CURRENT_DATE + cast(cast(i as text) || ' month' as interval))) 
        < extract(year from (CURRENT_DATE + cast('1 year' as interval)))
    LOOP
        text_interval = cast(intervalo as text) || ' month';
        i := i + 1;
        SELECT INTO cont COUNT(id) FROM faxina 
                WHERE data = CURRENT_DATE + cast(text_interval as INTERVAL) +  
                cast((cast(cont_dias as text) || ' days') as interval)  + 
                cast('8:00:00' as time);        
        IF cont != 0 THEN
            WHILE 
                cont != 0
            LOOP
                cont_dias := cont_dias + 1;
                SELECT INTO cont COUNT(id) FROM faxina 
                    WHERE data = CURRENT_DATE + cast(text_interval as INTERVAL) + 
                    cast((cont_dias || ' days') as interval) 
                    + cast('8:00:00' as time);
                IF (cont!=0) THEN
                    EXIT;
                END IF;
            END LOOP;
        ELSE 
            SELECT INTO valor_real_tamanho t.valor from faxina f 
            right join residencia r on r.id = f.id_residencia 
            inner join tamanho t on t.id = r.id_tamanho where r.id= cod_residencia limit 1;

            INSERT INTO faxina (id_residencia, id_diarista,data, valor) VALUES 
            (cod_residencia,cod_diarista, 
            CURRENT_DATE + cast(text_interval as INTERVAL) +  
            cast((cast(cont_dias as text) || ' days') as interval)  + 
            cast('8:00:00' as time), valor_real_tamanho);
            intervalo := intervalo +1;
        END IF;
    END LOOP;
--  ELSE 

  END IF;
  IF valor in ('Quinzenalmente') THEN
    while 
        extract(year from (CURRENT_DATE + cast(cast(cont_dias as text) || ' days' as interval))) 
        < extract(year from (CURRENT_DATE + cast('1 year' as interval)))
    LOOP
        i := i + 1;
        SELECT INTO cont COUNT(id) FROM faxina 
                WHERE data = CURRENT_DATE +  
                cast((cast(cont_dias as text) || ' days') as interval)  + 
                cast('8:00:00' as time);        
        IF cont != 0 THEN
            WHILE 
                cont != 0
            LOOP
                cont_dias := cont_dias + 1;
                SELECT INTO cont COUNT(id) FROM faxina 
                    WHERE data = CURRENT_DATE + 
                    cast((cont_dias || ' days') as interval) 
                    + cast('8:00:00' as time);
                IF (cont!=0) THEN
                    EXIT;
                END IF;
            END LOOP;
        ELSE 
            SELECT INTO valor_real_tamanho t.valor from faxina f 
            right join residencia r on r.id = f.id_residencia 
            inner join tamanho t on t.id = r.id_tamanho where r.id=cod_residencia limit 1;
            INSERT INTO faxina (id_residencia, id_diarista,data, valor) VALUES 
            (cod_residencia,cod_diarista, 
            CURRENT_DATE +
            cast((cast(cont_dias as text) || ' days') as interval)  + 
            cast('8:00:00' as time), valor_real_tamanho);
        END IF;
        cont_dias := cont_dias + 15;
    END LOOP;
    END IF;

END;
$$ LANGUAGE 'plpgsql';




-- CREATE OR REPLACE FUNCTION presenca(integer) RETURNS void AS
-- $$
-- DECLARE
 
-- BEGIN

-- DELETE DIARISTA WHERE total * (quantas_vezes_ela_foi/100) < 0.75;
 
-- END;
-- $$ LANGUAGE 'plpgsql';

-- CREATE FUNCTION deletar() RETURNS TRIGGER AS
-- $$
-- BEGIN
--  DELETE FROM faxina where id = 1;
--  return new;
-- END;
-- $$ LANGUAGE 'plpgsql';

-- CREATE TRIGGER deletar AFTER INSERT ON faxina
-- FOR EACH ROW EXECUTE PROCEDURE deletar();
