-- Adiciona validação e procedure de cpf -- feitoria
-- mudar id_responsavel como pk pra cpf responsavel -- feitoria
-- adicionar validação em tamanho -- feitoria
-- mudar chave unica de faxina para ter data junto -- feitoria
drop if exists database gerenciadorDeFaxinas;
create database gerenciadorDeFaxinas;

drop if exists table diarista;
drop if exists table responsavel;
drop if exists table tamanho;
drop if exists table residencia;
drop if exists table faxina;

drop if exists function validaCpf;
drop if exists function agendar_faxina;
drop if exists function porcentagem_presenca;

CREATE OR REPLACE FUNCTION validaCpf(character(11)) RETURNS boolean AS
$$
DECLARE
    resultado BOOLEAN;
    cpf ALIAS FOR $1;
    nro1 INTEGER;
    nro2 INTEGER;  
    nro3 INTEGER;
    nro4 INTEGER;
    nro5 INTEGER;
    nro6 INTEGER;
    nro7 INTEGER;
    nro8 INTEGER;
    nro9 INTEGER;
    nro10 INTEGER;
    nro11 INTEGER;
    soma INTEGER;
    resto INTEGER;
    resultadoDigito1 BOOLEAN;
    resultadoDigito2 BOOLEAN;
BEGIN
    -- 66167566020
    resultado := FALSE;
    resultadoDigito1 := FALSE;
    resultadoDigito2 := FALSE;
    IF cpf is NULL THEN
        RETURN FALSE;
    END IF;
    IF LENGTH(cpf) != 11 THEN
        RETURN FALSE;
    END IF;
    IF cpf = '00000000000' or 
		cpf = '11111111111' or 
		cpf = '22222222222' or 
		cpf = '33333333333' or 
		cpf = '44444444444' or 
		cpf = '55555555555' or 
		cpf = '66666666666' or 
		cpf = '77777777777' or 
		cpf = '88888888888' or 
		cpf = '99999999999' THEN
        return FALSE;
    END IF;
    nro1 := SUBSTRING(cpf,1, 1);
--    RAISE NOTICE '%', nro1;
    nro2 := SUBSTRING(cpf,2, 1);
--    RAISE NOTICE '%', nro2;    
    nro3 := SUBSTRING(cpf,3, 1);
--    RAISE NOTICE '%', nro3;
    nro4 := SUBSTRING(cpf,4, 1);
--    RAISE NOTICE '%', nro4;
    nro5 := SUBSTRING(cpf,5, 1);
--    RAISE NOTICE '%', nro5;
    nro6 := SUBSTRING(cpf,6, 1);
--    RAISE NOTICE '%', nro6;
    nro7 := SUBSTRING(cpf,7, 1);
--    RAISE NOTICE '%', nro7;
    nro8 := SUBSTRING(cpf,8, 1);
--    RAISE NOTICE '%', nro8;
    nro9 := SUBSTRING(cpf,9, 1);
--    RAISE NOTICE '%', nro9;
    nro10 := SUBSTRING(cpf,10, 1);
--    RAISE NOTICE '%', nro10;
    nro11 := SUBSTRING(cpf,11, 1);
--    RAISE NOTICE '%', nro11;
--    DIGITO 1
    soma := nro1 * 10 + nro2 * 9 + nro3 * 8 + nro4 * 7 + nro5 * 6 + nro6 * 5 + nro7 * 4 + nro8 * 3 + nro9 * 2;
    resto := (soma * 10) % 11;   
    IF resto = 10 THEN
        resto := 0;
    END IF;
    IF resto = nro10 THEN
        resultadoDigito1 := TRUE;
    END IF;
--  DIGITO 2
    soma := nro1 * 11 + nro2 * 10 + nro3 * 9 + nro4 * 8 + nro5 * 7 + nro6 * 6 + nro7 * 5 + nro8 * 4 + nro9 * 3 + nro10 * 2;
    resto := (soma * 10) % 11;   
    IF resto = 10 THEN
        resto := 0;
    END IF;    
    IF resto = nro11 THEN
        resultadoDigito2 := TRUE;
    END IF;
    resultado := resultadoDigito1 AND resultadoDigito2;
    return resultado;
END;
$$ LANGUAGE 'plpgsql';

create table diarista(
    id serial primary key,
    cpf text not null check(validaCpf = true),
    nome text not null
);

create table responsavel(
    cpf text not null primary key,
    nome text not null
);

create table tamanho(
    id serial primary key,
    tamanho text not null check (tamanho = 'pequena' or tamanho = 'média' or tamanho = 'grande'),
    preco numeric(10,2)
);

create table residencia(
    id serial primary key,
    id_tamanho integer not null references tamanho(id),
    cpf_responsavel text not null references responsavel(cpf),
    cidade text not null,
    bairro text not null,
    rua text not null,
    complemento text,
    numero text not null
);

create table faxina(
    id_residencia integer not null references residencia(id),
    id_diarista integer not null references diarista(id),
    data date not null,
    avaliacao text,
    valor_final numeric(10,2),
    realizada boolean,
    unique(id_residencia, id_diarista, data)
);

create or replace function agendar_faxina(id_diarista integer, id_residencia integer, periodicidade integer) returns text as $$
	declare
		faxinas_agendadas integer;
		maximo_faxinas integer := 30;
		data_agendamento date := current_date;
	begin
		select count(*) into faxinas_agendadas from faxina where 
			faxina.data >= current_date and 
			faxina.id_diarista = $1 and
			faxina.id_residencia = $2;
		if faxinas_agendadas < maximo_faxinas then
			while faxinas_agendadas < maximo_faxinas loop
				data_agendamento := data_agendamento + $3;
				select * from faxina where faxina.id_diarista = $1 and faxina.data = data_agendamento;
				if not found then
					insert into faxina(id_diarista, id_residencia, data) values($1, $2, data_agendamento);
				
					faxinas_agendadas := faxinas_agendadas + 1;
				end if;
			end loop;	
		else
			return 'maximo de faxina estourado';
		end if;
		return 'faxinas marcadas com sucesso';
	end;
$$ language plpgsql;

insert into diarista(cpf, nome) values('87356104091', 'Jorge');
insert into tamanho(tamanho, preco) values('pequena', 120.0);
insert into tamanho(tamanho, preco) values('média', 150.0);
insert into tamanho(tamanho, preco) values('grande', 200.0);
insert into responsavel(cpf, nome) values('12312312312', 'Renatinho');
insert into residencia(id_tamanho, cpf_responsavel, cidade, bairro, rua, complemento, numero)
	values(1, '12312312312', 'Rio Grande', 'Parque Coelho', 'Av Presidente Vargas', 'bloco 10b ap 101', '445');
insert into faxina(id_residencia, id_diarista, data)
	values(1, 1, '2022-07-27');

update faxina set realizada = true where data <= '2023-04-21';
update faxina set realizada = false where realizada is null;
select * from faxina;

create or replace function porcentagem_presenca(id_diarista integer) returns real as $$
	declare
		total_faxinas integer;
		faxinas_realizadas integer;
		porcentagem real;
	begin
		select count(*) into total_faxinas from faxina where faxina.id_diarista = $1;
		select count(*) into faxinas_realizadas from faxina where faxina.id_diarista = $1 and realizada = true;
		
		return (100.0 * faxinas_realizadas)/total_faxinas;
	end;
$$ language plpgsql;

create or replace function deleta_diarista_ausente() returns trigger as $$
	declare
		total_faxinas integer;
	begin
		select count(*) into total_faxinas from faxina where faxina.id_diarista = new.id_diarista and faxina.realizada is not null;
		if total_faxinas >= 5 then
			
			if porcentagem_presenca(new.id_diarista) < 75 then
				delete from faxina where faxina.id_diarista = new.id_diarista;
				delete from diarista where id = new.id_diarista;
			end if;
		end if;
		return null;
	end;
$$ language plpgsql;

create trigger deleta_diarista_ausente after update on faxina for each row execute procedure deleta_diarista_ausente();

insert into diarista(cpf, nome) values('79689919008', 'jorginho');

insert into faxina(id_residencia, id_diarista, data)
	values(1, 2, '2022-05-10');
insert into faxina(id_residencia, id_diarista, data)
	values(1, 2, '2022-07-29');
insert into faxina(id_residencia, id_diarista, data)
	values(1, 2, '2022-07-30');
insert into faxina(id_residencia, id_diarista, data)
	values(1, 2, '2022-07-31');
insert into faxina(id_residencia, id_diarista, data)
	values(1, 2, '2022-08-01');
	
update faxina set realizada = false where faxina.id_diarista = 2 and faxina.data = '2022-05-10';
update faxina set realizada = false where faxina.id_diarista = 2 and faxina.data = '2022-07-29';
update faxina set realizada = false where faxina.id_diarista = 2 and faxina.data = '2022-07-30';
update faxina set realizada = false where faxina.id_diarista = 2 and faxina.data = '2022-07-31';
update faxina set realizada = false where faxina.id_diarista = 2 and faxina.data = '2022-08-01';