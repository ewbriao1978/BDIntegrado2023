-- criação das tabelas ---------------------------------------------------------------------------------------
drop database if exists faxinas;
create database faxinas;

\c faxinas;

-- criação das tabelas ---------------------------------------------------------------------------------------
drop table if exists faxina;
drop table if exists residencia;
drop table if exists tamanho;
drop table if exists responsavel;
drop table if exists diarista;

create table if not exists diarista (
	id serial primary key,
	cpf char(14) unique not null,
	nome varchar(150)
);

create table if not exists responsavel (
	id serial primary key,
	cpf char(14) unique not null,
	nome varchar(150)
);

create table tamanho (
	id serial primary key,
	descricao varchar(50) unique not null,
	valor numeric(10, 2) not null
);

create table if not exists residencia (
	id serial primary key,
	cidade varchar(150),
	bairro varchar(150),
	rua varchar(150),
	numero varchar(10),
	complemento varchar(250),
	id_tamanho integer not null references tamanho (id),
	id_responsavel integer not null references responsavel (id)
);

create table if not exists faxina (
	id serial primary key,
	preco numeric(10,2) not null default 0.0,
	valor_pago numeric(10,2) not null default 0.0,
	data date,
	presenca boolean default null,
	feedback text not null default 'Aguardando feedback...',
	id_diarista integer not null references diarista (id) on delete cascade,
	id_residencia integer not null references residencia (id)
);

-- store procedure de agendamento de faxina -------------------------------------------------------------------
drop function if exists agendar_faxina(integer, integer, integer, varchar);
drop function if exists percentualizar_presenca(integer);

create function agendar_faxina(diarista_id integer, residencia_id integer, numero_faxinas integer, intervalo varchar)
returns void as 
$$
declare
	data_agendada date := current_date;
begin
	for contador in 1..numero_faxinas loop
		if intervalo = 'quinzenal' then 
			data_agendada = data_agendada + interval '15 days';
		elseif intervalo = 'mensal' then
			data_agendada = data_agendada + interval '1 month';
		else 
			raise exception 'Opcao de intervalo inexistente';
		end if;
		
		insert into faxina (data, id_diarista, id_residencia) values
		(data_agendada, diarista_id, residencia_id);
		
	end loop;
	
	raise notice 'Faxinas agendadas com sucesso!';
end;
$$ language 'plpgsql';

-- store procedure de cálculo de porcentagem de presença dos diaristas -----------------------------------------
create function percentualizar_presenca(diarista_id integer)
returns numeric(5,2) as
$$
declare
	percentual numeric(5,2);
	numero_faxinas real;
	numero_presenca real;
	ano_atual integer;
begin
	select extract(year from current_date) into ano_atual;
	
	select count(*) from faxina
		where id_diarista = diarista_id
		and presenca is not null
		and   (select extract(year from data)) = ano_atual
		into numero_faxinas;
		
	select count(*) from faxina 
		where id_diarista = diarista_id
		and   (select extract(year from data)) = ano_atual
		and   presenca = true
		into numero_presenca;
	
	select (numero_presenca / numero_faxinas) * 100 into percentual;
	
	return percentual;
end;
$$ language 'plpgsql';

-- funções disparadas por triggers -----------------------------------------------------------------------------
drop function if exists checar_data();
drop function if exists ajustar_faxina();
drop function if exists checar_presenca(); 

-- checagem de data
create function checar_data() 
returns trigger as
$$
declare
	tupla_faxina record;
begin
	-- não permitir a inserção de 2 faxinas com a mesma faxineira em datas iguais
	for tupla_faxina in select data, id_diarista from faxina
	loop
		if (tupla_faxina.data = new.data and tupla_faxina.id_diarista = new.id_diarista) then
			raise exception 'O diarista ja tem uma faxina marcada nessa data';
		end if;
	end loop;
	
	return new;
end
$$ language 'plpgsql';

-- ajuste de preco e remoção de valor pago em caso de ausência
create function ajustar_faxina()
returns trigger as
$$
declare
	preco_tamanho numeric;
begin
	-- ajustar preco conforme tamanho da residência
	select tamanho.valor from tamanho
	inner join residencia on (tamanho.id = residencia.id_tamanho)
	inner join faxina on (faxina.id_residencia = residencia.id)
	where faxina.id = new.id
	into preco_tamanho;
	
	update faxina set preco = preco_tamanho where faxina.id = new.id;  
	
	-- remover valor pago caso o diarista não realize a faxina
	if new.presenca = false then 
		update faxina set valor_pago = 0.0 where faxina.id = new.id;
	end if;
	
	return new;
end
$$ language 'plpgsql';

-- exclusão de diarista com presenças menores que 75%
create function checar_presenca()	
returns trigger as 
$$
declare
	percentual numeric(5,2);
	faxineira_existe boolean := true;
begin
	if (select count(*) from faxina where faxina.id_diarista = new.id_diarista) >= 5  then 

		select percentualizar_presenca(new.id_diarista) into percentual;

		if percentual < 75.00 then
			delete from diarista where diarista.id = new.id_diarista;
		end if;
	end if;
	return new;
end;
$$ language 'plpgsql';

-- triggers ----------------------------------------------------------------------------------------------------
drop trigger if exists t_checagem_data on faxina;
drop trigger if exists t_checagem_presenca on faxina;	
drop trigger if exists t_insercao_atualizao_faxina on faxina;
drop trigger if exists t_atualizao_tamanho on tamanho;

create trigger t_checagem_data
before insert or update of data
on faxina
for each row
execute procedure checar_data();

create trigger t_insercao_faxina
after insert or update
on faxina
for each row 
when (pg_trigger_depth() = 0) -- fonte: https://pt.stackoverflow.com/questions/287609/atualizar-coluna-em-tabela-postgresql
execute procedure ajustar_faxina();

create trigger t_atualizao_tamanho
after update of valor
on tamanho
for each row 
when (pg_trigger_depth() = 0) -- fonte: https://pt.stackoverflow.com/questions/287609/atualizar-coluna-em-tabela-postgresql
execute procedure ajustar_faxina();

-- trigger de exclusão de diarista com presenças menores que 75%
create trigger t_checagem_presenca	
after insert or update of presenca
on faxina
for each row 
execute procedure checar_presenca();

-- inserções nas tabelas --------------------------------------------------------------------------------------
insert into diarista (cpf, nome) values
('993.416.410-80', 'Doriana Negreiros Caminha'),
('778.466.700-00', 'Viviana Curado Lancastre'),
('988.647.950-73', 'Kaio Goulão Protásio'),
('984.667.740-50', 'Edgar Ninharelhos Guterres'),
('166.196.310-29', 'Aline Antas Valim'),
('782.047.500-56', 'Jasmine Afonso Valentim'),
('650.877.920-65', 'Haniel Curvelo Figueiroa');

insert into responsavel (cpf, nome) values
('148.725.700-73', 'Aysha Ornelas Monforte'),
('086.063.890-13', 'Eli Imperial Lampreia'),
('755.736.140-70', 'Sílvia Sacadura Lemos'),
('318.273.000-27', 'Elói Lemes Lemos');

insert into tamanho (descricao, valor) values
('pequena', 210.90),
('media', 360.80),
('grande', 440.30);

insert into residencia (cidade, bairro, rua, numero, complemento, id_responsavel, id_tamanho) values 
('Rio Grande', 'Cassino', 'Rua do Cemiterio', '10', 'Casa', 1, 2),
('Rio Grande', 'Bolaxa', 'Rua A', '13B', 'Casa', 1, 1),
('Rio Grande', 'Parque Marinha', 'Rua dos Lagos', '1234', 'Sobrado', 2, 3),
('Rio Grande', 'Cidade Nova', 'Avenida Pelotas', '118', 'Apartamento 113', 3, 1),
('Sao Jose do Norte', 'Centro', 'Onion Boulevard', '57A', 'Casa', 4, 2);

insert into faxina (valor_pago, data, presenca, feedback, id_diarista, id_residencia) values 
(380.80, '2022-07-02', true, 'Gostei muito. Dei gorjeta pelo bom serviço!', 1, 1),
(360.80, '2022-08-20', true, 'OK.', 1, 1),
(100.00, '2022-09-01', false, 'Não compareceu.', 1, 1),
(340.20, '2022-07-01', true, 'Bom.', 2, 3),
(290.20, '2022-07-02', true, 'Quebrou vários pratos.', 3, 5),
(100.00, '2022-08-01', false, 'Não compareceu.', 4, 3),
(210.90, '2022-08-07', true, 'Serviço razoável.', 5, 4),
(210.90, '2022-09-07', true, 'Serviço razoável.', 6, 4),
(250.90, '2022-10-07', true, 'Serviço muito bom.', 7, 4),
(100.00, '2022-11-07', false, 'Não compareceu ao local.', 7, 4);

-- testes ----------------------------------------------------------------------------------------------------
-- teste do store procedure de agendamento de consulta
-- select agendar_faxina(2, 1, 3, 'mensal');
-- select agendar_faxina(3, 2, 7, 'quinzenal');
-- select agendar_faxina(1, 1, 4, 'semanal');

-- teste do trigger de inserção de 2 faxinas com a mesma faxineira em datas iguais
-- insert into faxina (data, id_diarista, id_residencia) values ('2022-07-02', 1, 2);

-- teste do store procedure de cálculo de porcentagem de presença dos diaristas
-- select percentualizar_presenca(1);
-- select percentualizar_presenca(2);
-- select percentualizar_presenca(3);
-- select percentualizar_presenca(4);

-- teste do trigger de exclusão de diarista com presenças menores que 75%
select count(*) as "numero de faxinas" from faxina where id_diarista = 1; -- 3 faxinas!

insert into faxina (valor_pago, data, presenca, feedback, id_diarista, id_residencia) values 
(100.00, '2022-12-01', false, 'Não compareceu.', 1, 1),
(100.00, '2022-12-02', false, 'Não compareceu.', 1, 1);

select * from diarista;
select * from faxina;