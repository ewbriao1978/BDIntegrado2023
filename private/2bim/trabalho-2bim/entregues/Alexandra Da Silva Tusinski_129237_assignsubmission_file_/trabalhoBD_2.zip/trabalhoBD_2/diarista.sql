DROP DATABASE IF EXISTS diarista;


CREATE DATABASE diaria;

\c diarista;

crate table diarista(
    id serial primary key,
    cpf varchar(11) not null,
    nome text
    
);

insert into diarista(cpf, nome) values
('11111111111', 'carla'),
('22222222222', 'debora'),
('33333333333', 'Vanessa');


create table responsavel(
    id serial primary key,
    nome text,
    cpf varchar(11)
);

insert into responsavel(nome, cpf) values
('carlos', '44444444444'),
('joao', '55555555555'),
('magda', '66666666666');


create table residencia(
    id serial primary key,
    cidade text,
    bairro text,
    rua text,
    complemento text,
    numero text,
    tamanho text,
    id_responsavel integer references responsavel(id),
    CONSTRAINT CHECK_tamanho CHECK ( tamanho in ('pequena','media','grande'))
);

INSERT INTO residencia (tamanho_residencia) VALUES ('pequena');
INSERT INTO residencia (tamanho_residencia) VALUES ('media');
INSERT INTO residencia (tamanho_residencia) VALUES ('grande');

insert into residencia(cidade, bairro, rua, complemento, numero, tamanho, id_responsavel) values
('rio grande', 'cidade nova', 'buarque macedo', null, '110', 1, 1),
('rio grande', 'centro', 'andradas', null, '11', 2, 2),
('rio grande', 'cassino', 'atlantica', 'a', '1470', 3, 3);

create table faxina(
    id serial primary key,
    valor real,
    pagamento boolean,
    danos real,
    gorjeta real,
    id_diarista integer references diarista(id),
    id_residencia integer references residencia(id)

);

insert into faxina(valor, data, pagamento, danos, gorjeta, id_diarista, id_residencia)values
(170.00,  't', null, null, 1, 1),
(120.00,  't', null, 10.00, 2, 2),
(100.00,  't', null, 5.00, 3, 3),
(120.00,  'f', null, null, 2, 2),
(100.00,  null, null, null, 1, 3);


create table agenda(
    id serial primary key,
    dataAgenda date,
    dataFaxina date,
    dataCancelamento date,
    id_diarista integer references diaria(id),
    id_residencia integer references residencia(id),
    id_faxina integer references faxina(id)
);

insert into agenda(dataAgenda, dataFaxina, dataCancelamento, id_diarista, id_residencia, id_faxina) values
('22/07/10', '22/07/10', null, 1, 1,1),
('22/07/08', '22/07/08', null, 2, 2, 2),
('22/07/07', '22/07/07', null, 3, 3, 3),
('22/08/01', null, null, 2, 2, 4),
('22/08/03', null, '22/07/27',1, 3, 5);

create table avaliacao(
    id serial primary key,
    faxinaAvaliacao text,
    id_residencia integer references residencia(id),
    id_responsavel integer references responsavel(id)
    CONSTRAINT CHECK_faxinaAvaliacao CHECK ( faxinaAvaliacao in 
        ('uma estrela','duas estrelas','três estrelas', 'quatro estrelas', 'cinco estrelas'))
);

INSERT INTO avaliacao (faxinaAvaliacao_residencia) VALUES ('uma estrela');
INSERT INTO avaliacao (faxinaAvaliacao_residencia) VALUES ('duas estrela');
INSERT INTO avaliacao (faxinaAvaliacao_residencia) VALUES ('três estrela');
INSERT INTO avaliacao (faxinaAvaliacao_residencia) VALUES ('quatro estrela');
INSERT INTO avaliacao (faxinaAvaliacao_residencia) VALUES ('cinco estrela');

insert into avaliacao(faxinaAvaliacao, id_residencia, id_responsavel) values
(4, 1, 1),
(5, 2, 2),
(4, 3, 3);









