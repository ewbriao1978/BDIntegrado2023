DROP DATABASE IF EXISTS faxina;

CREATE DATABASE faxina;

\c faxina

CREATE TABLE diarista (
    id serial PRIMARY KEY,
    cpf varChar(11) UNIQUE NOT NULL,
    nome text not null
);

CREATE TABLE tamanho (
    id serial PRIMARY KEY,
    tipo text CHECK (tipo = 'pequeno' or tipo = 'medio' or tipo = 'grande'),
    valor real not null
);

CREATE TABLE responsavel (
    cpf varChar(11) UNIQUE PRIMARY KEY,
    nome text not null
);

CREATE TABLE residencia (
    id serial PRIMARY KEY,
    cidade text,
    bairro text,
    rua text,
    numero integer,
    complemento text,
    tamanho_id integer REFERENCES tamanho (id),
    responsavel_cpf varChar(11) REFERENCES responsavel (cpf)
);

CREATE TABLE faxina (
    id serial PRIMARY KEY,
    ehAgendada boolean,
    data date,
    valor real,
    faltou boolean, 
    descontoPorDano real,
    gorjeta real,
    diarista_id integer references diarista (id),
    residencia_id integer references residencia (id),
    UNIQUE (diarista_id, data, residencia_id)
);


create table freq (
    id serial PRIMARY KEY,
    valor real,
    diarista_id integer
    );



insert into diarista values 
(1, '14536585678', 'henrique'),
(2, '45712365921', 'felipe'),
(3, '95486525654', 'justo'),
(4, '02380772271', 'jose maria');
insert into responsavel values 
('05604878986', 'moises'),
('45612378985', 'joao'),
('96385274145', 'guilherme'),
('78915935756', 'pericles');

insert into tamanho values 
(1, 'pequeno', 100),
(2, 'medio', 150),
(3, 'grande', 200);

insert into residencia values 
(1, 'rg', 'cdn', 'buarque', 3, 'quadra', 1, '45612378985'),
(2, 'pel', 'marco', 'fregues', 4, 'c4', 2, '05604878986'),
(3, 'rs', 'centro', 'paz', 5, 'c5', 3, '96385274145'),
(4, 'pa', 'braz', 'vargas', 6, 'c6', 2, '96385274145');



create function frequencia(integer) returns real as
$$
DECLARE
totalFaxina real;
presenca real;
frequenciaTotal real;
numeroFaxinas integer;
BEGIN

select into totalFaxina count(*) from faxina where diarista_id = $1;
if (totalFaxina > 5) then
select into presenca count(*) from faxina where diarista_id = $1 and faltou = false;
select into frequenciaTotal (presenca / totalFaxina) * 100;
insert into freq (valor, diarista_id) values (frequenciaTotal, $1);
return frequenciaTotal;
ELSE
raise notice 'faxinas isuficientes';
end if;


END;
$$
LANGUAGE 'plpgsql';



create function apagar() returns trigger as
$$
BEGIN
if (NEW.valor < 75) then
    delete from faxina where diarista_id = NEW.diarista_id;
    delete from freq where diarista_id = NEW.diarista_id;
    delete from diarista where id = NEW.diarista_id;
END IF;
return OLD;
END;
$$
LANGUAGE 'plpgsql';

create trigger apagar_gatilho after insert on freq for each row execute procedure apagar();



CREATE or REPLACE function CalcValorFinal(diarista_id integer, faxina_id INTEGER) returns void as
$$
DECLARE
valorTamanho integer;
BEGIN
select into valorTamanho from residencia where residencia.tamanho_id;
END;
$$
LANGUAGE 'plpgsql';





create function agendar(diarista_id integer, residencia_id integer, frequencia integer, numeroDeFaxinas integer, dataLimite date) returns void as
$$
DECLARE
i integer;
dataAuxiliar date;
BEGIN
if (frequencia = 30 or frequencia = 15) then
    dataAuxiliar = CURRENT_DATE;
    for i in 1..numeroDeFaxinas loop
    if (dataAuxiliar+frequencia < dataLimite) then
    insert into faxina (ehAgendada, data, valor, faltou, descontoPorDano, gorjeta, diarista_id, residencia_id) values (true, dataAuxiliar+frequencia, (select valor from residencia inner join
    tamanho on (residencia.tamanho_id = tamanho.id) where residencia.id = $2), false,0.0,0.0,diarista_id,residencia_id);
    dataAuxiliar = dataAuxiliar + frequencia;
    end if;
    end loop;
ELSE
raise notice 'frequencia não permitida';
END IF;
END;
$$
LANGUAGE 'plpgsql';







