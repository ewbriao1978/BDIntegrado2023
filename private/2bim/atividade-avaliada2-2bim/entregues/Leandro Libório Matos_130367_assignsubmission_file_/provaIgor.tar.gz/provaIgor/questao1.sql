drop database if exists questao1;
create database questao1;
\c questao1

create table funcionario (
    cpf varChar(11) primary key unique,
    nome text not null,
    data_nasc date not null,
    nacionalidade text not null,
    sexo char not null,
    estado_civil text not null,
    endereco text not null,
    rg text not null unique,
    data_admissao date not null,
    telefone integer not null
);

create table cargo_ocupado (
    id serial primary key not null,
    cargo text  not null,
    dt_inicio date not null,
    dt_fim date not null,
    funcionario_cpf varChar(11) references funcionario (cpf)
);

create table dependente (
    id serial primary key not null,
    nome text not null,
    data_nasc text not null,
    funcionario_cpf varChar(11) references funcionario (cpf)
);
