package questao2.modelo;

import java.util.ArrayList;

/**
 * funcionario
 */
public class Funcionario {
    private String cpf;
    private String nome;
    private String estadoCivil;
    private String endereco;
    private String nacionalidade;
    private String rg;
    private String telefone;
    private String sexo;
   

    public Funcionario(String cpf, String nome, String estadoCivil, String endereco, String nacionalidade, String rg,
            String telefone, String sexo) {
        this.cpf = cpf;
        this.nome = nome;
        this.estadoCivil = estadoCivil;
        this.endereco = endereco;
        this.nacionalidade = nacionalidade;
        this.rg = rg;
        this.telefone = telefone;
        this.sexo = sexo;
    }

    
    }

    public Funcionario() {
        
    }



    public String getCpf() {
        return this.cpf;
    }
    public String getNome() {
        return this.nome;
    }

    public String getEstadoCivil() {
        return this.estadoCivil;
    }
    public String getEndereco() {
        return this.endereco;
    }
    public String getNacionalidade() {
        return this.nacionalidade;
    }
    public String getRg() {
        return this.rg;
    }
    public String getTelefone() {
        return this.telefone;
    }
    public String getSexo() {
        return this.sexo;
    }


    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }
    public void setRg(String rg) {
        this.rg = rg;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }





















     
}

