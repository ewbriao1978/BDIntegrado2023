import java.sql.SQLException;

import questao2.modelo.Funcionario;
import questao2.persistencia.FuncionarioDAO;

public class MainInserir {
    
    public static void main(String[] args) throws SQLException {
    
    Funcionario f = new Funcionario();
    f.setCpf("11111111111");
    f.setNome("Igor");
    f.setEstadoCivil("casado");
    f.setEndereco("rio grande");
    f.setNacionalidade("brasileiro");
    f.setRg("784546");
    f.setTelefone("53999999999");
    f.setSexo("masculino");  
     boolean resultado = new FuncionarioDAO().inserir(f);
    System.out.println("Deu certo?"+resultado);
    System.out.println("Qual cpf:"+f.getCpf());
    

    
    }
}