import java.sql.*;
import java.sql.ResultSet;
import java.util.ArrayList;


import questao2.modelo.Funcionario;
 

public class FuncionarioDAO {   
    public boolean inserir(Funcionario funcionario) throws SQLException {
    boolean resultado = false;
    String sql = "INSERT INTO funcionario(cpf,nome,estado_civil, endereco, nacionalidade, rg, telefone, sexo) VALUES (?,?,?,?,?,?,?,?) RETURNING cpf;";
    Connection connection = new ConexaoPostgreSQL().getConexao();
    PreparedStatement preparedStatement = connection.prepareStatement(sql);
    preparedStatement.setString(1, funcionario.getCpf());
    preparedStatement.setString(2, funcionario.getNome());
    preparedStatement.setString(3, funcionario.getEstadoCivil());
    preparedStatement.setString(4, funcionario.getEndereco());
    preparedStatement.setString(5, funcionario.getNacionalidade());
    preparedStatement.setString(6, funcionario.getRg());
    preparedStatement.setString(7, funcionario.getTelefone());
    preparedStatement.setString(8, funcionario.getSexo());    
    ResultSet rs = preparedStatement.executeQuery();
    if (rs.next()) {
    funcionario.setCpf(rs.getString("cpf"));
    resultado = true;
    }
    preparedStatement.close();
    connection.close();
    return resultado;    
    }
    
    
    
    
    }