drop database if exists ficha;
create database ficha;

\c ficha

create table paciente (
    numero serial primary key unique,
    nome text not null,
    data_nasc date not null,
    sexo text not null,
    convenio text not null,
    est_civil text not null,
    rg text not null,
    telefone text not null
);

create table medico (
    crm integer primary key unique,
    nome text not null
);

create table consulta (
    numero serial primary key unique,
    data date not null,
    diagnostico text not null,
    paciente_numero integer references paciente (numero),
    medico_crm integer references medico (crm)
);

create table exame (
    id serial primary key,
    nome text not null,
    data date not null,
    consulta_numero integer references consulta (numero)
);
-------------------------------------------------------
--QUESTAO 04
-------------------------------------------------------

create user fulano with password 'fulano' superuser;
create user ciclano with password 'ciclano' nosuperuser;
grant select on all tables in schema public to ciclano;