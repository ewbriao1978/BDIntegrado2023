DROP DATABASE IF EXISTS clinica;

CREATE DATABASE clinica;

\c clinica;


CREATE TABLE Convenio(
    id serial PRIMARY KEY,
    nome text
); --me deu um branco aqui esqueci oq é um convenio kkkkkkkkkkkk espero que não interfira na prova 

CREATE TABLE Paciente(
    id serial PRIMARY KEY,
    nome text,
    data_nascimento date,
    sexo text,
    Convenio_id INTEGER REFERENCES Convenio(id),
    estado_civil text,
    RG char(14),
    telefone INTEGER,
    endereco text
);

CREATE TABLE Medico(
    id serial PRIMARY KEY,
    nome text,
    CRM INTEGER UNIQUE
);

CREATE TABLE Consulta(
    id serial PRIMARY KEY,
    data_consulta date,
    Medico_CRM INTEGER REFERENCES Medico(CRM),
    numero_Paciente INTEGER REFERENCES Paciente(id),
    diagnostico text
);

CREATE TABLE Exame(
    id serial PRIMARY KEY,
    numero_Consulta INTEGER REFERENCES Consulta(id),
    exame text,
    data_exame date
);

DROP ROLE IF EXISTS fulano;
CREATE ROLE fulano PASSWORD 'fulano' SUPERUSER;

DROP ROLE IF EXISTS ciclano;
CREATE ROLE ciclano PASSWORD 'ciclano';
GRANT SELECT ON ALL TABLES IN SCHEMA public  TO ciclano;