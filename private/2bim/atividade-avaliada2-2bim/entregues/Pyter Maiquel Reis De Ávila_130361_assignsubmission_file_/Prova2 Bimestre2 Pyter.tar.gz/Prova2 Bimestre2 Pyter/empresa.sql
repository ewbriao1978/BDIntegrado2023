DROP DATABASE IF EXISTS empresa;

CREATE DATABASE empresa;

\c empresa;

CREATE TABLE Funcionario(
    id serial PRIMARY KEY,
    nome text,
    cpf char(11) UNIQUE,
    estado_civil text,
    data_nascimento date,
    nacionalidade text,
    sexo text,
    telefone INTEGER,
    endereco text,
    data_admissao date,
    RG char(14) -- esqueci quantos digito é um RG chutei essa
);

CREATE TABLE Ocupacao(
    id serial PRIMARY KEY,
    cargo text,
    data_inicio date,
    date_fim date,
    Funcionario_id INTEGER REFERENCES Funcionario(id)
);

CREATE TABLE Dependentes (
    id serial PRIMARY KEY,
    nome text,
    data_nascimento date,
    Funcionario_id INTEGER REFERENCES Funcionario(id) UNIQUE
);

INSERT INTO Funcionario(nome,cpf,estado_civil,nacionalidade,sexo,telefone,endereco) VALUES ('Toku Komichao Notoba',12345678911,'solteiro','Brasileiro','todos',84028922,'Rua Aquela Lá número 3 Casa');
INSERT INTO Ocupacao(cargo,Funcionario_id) VALUES ('Desempenador de vidro',1);
INSERT INTO Dependentes (nome) VALUES ('Lactose, o Intolerante');