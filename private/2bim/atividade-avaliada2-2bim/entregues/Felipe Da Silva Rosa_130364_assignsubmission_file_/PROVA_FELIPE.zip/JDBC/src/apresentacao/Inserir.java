
package apresentacao;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Funcionario;
import persistencia.FuncionarioDAO;

public class Inserir {

    public static void main(String[] args) throws SQLException {
        Funcionario f = new Funcionario();
        f.setCpf("42870801068");
        f.setRg("6102849458");
        f.setNome("Felipe");
        f.setSexo("M");
        f.setEstadoCivil("Solteiro");
        f.setNacionalidade("Brasileiro");
        f.setTelefone("(53) 99149-6124");
        f.setEndereco("Avenida Major Carlos Pinto Nº: 119");
        boolean resultado = new FuncionarioDAO().inserir(f);
        System.out.println(resultado);
    }
}
