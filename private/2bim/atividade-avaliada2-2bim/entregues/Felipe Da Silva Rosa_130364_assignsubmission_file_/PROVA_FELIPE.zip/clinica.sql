DROP DATABASE IF EXISTS clinica;
CREATE DATABASE clinica;
\c clinica;

CREATE TABLE convenio (
    id serial PRIMARY KEY,
    descricao varchar(50) NOT NULL,
    valor_mensal real CHECK (valor_mensal > 0)
);

CREATE TABLE paciente (
    id serial PRIMARY KEY,
    nro_paciente integer NOT NULL,
    rg character(10),
    nome varchar(20) NOT NULL,
    dt_nasc date NOT NULL,
    sexo character (1) NOT NULL,
    estado_civil varchar(20),
    telefone varchar(15),
    endereco text,
    UNIQUE (nro_paciente)
);

CREATE TABLE medico (
    id serial PRIMARY KEY,
    crm varchar(10) NOT NULL,
    nome varchar(20) NOT NULL,
    especialidade text NOT NULL,
    UNIQUE (crm)
);

CREATE TABLE consulta (
    numero serial PRIMARY KEY,
    paciente_id integer REFERENCES paciente (id),
    medico_id integer REFERENCES medico (id),
    data date NOT NULL,
    diagnostico text NOT NULL
);

CREATE TABLE exame (
    id serial PRIMARY KEY,
    nome varchar(50) NOT NULL,
    valor real CHECK (valor > 0),
    consulta_numero integer REFERENCES consulta (numero)
);

INSERT INTO convenio (descricao, valor_mensal) VALUES
('Premier', 350.50),
('Standart', 100.00);

INSERT INTO paciente (nro_paciente, rg, nome, dt_nasc, sexo, estado_civil, telefone, endereco) VALUES
(20, '6102849459', 'Felipe', '1991-09-26', 'M', 'Solteiro', '(53) 991223377', 'Avenida Presidente Vargas Nº: 608'),
(40, '4564712867', 'Judith', '1990-01-12', 'F', 'Casada', '(53) 991496124', 'Rua Marechal Floriano Nº: 110');

INSERT INTO medico (crm, nome, especialidade) VALUES
('8402', 'Nicole', 'Cardiologista'),
('6581', 'Geraldo', 'Oftalmologista');

INSERT INTO consulta (paciente_id, medico_id, data, diagnostico) VALUES
(1, 1, '2022-06-26', 'Fazer mais exercicios físicos'),
(1, 2, '2022-05-21', 'Trocar óculos'),
(2, 2, '2022-05-19', 'Pressão Alta'),
(2, 1, '2022-06-15', 'Hipermetropia');

INSERT INTO exame (nome, valor, consulta_numero) VALUES
('Eletrocardiograma', 299.00, 1),
('Teste de visão', 160.00, 2),
('Chegagem de pressão', 50.00, 3),
('Análise ocular', 320.30, 4);

DROP USER IF EXISTS fulano;
CREATE USER fulano SUPERUSER;
ALTER USER FULANO with encrypted password '<password>';

DROP USER IF EXISTS ciclano;
CREATE USER ciclano WITH PASSWORD 'ciclano';
GRANT SELECT ON convenio TO ciclano;
GRANT SELECT ON paciente TO ciclano;
GRANT SELECT ON medico TO ciclano;
GRANT SELECT ON consulta TO ciclano;
GRANT SELECT ON exame TO ciclano;