DROP DATABASE IF EXISTS funcionario;
CREATE DATABASE funcionario;


\c funcionario;

CREATE TABLE funcionario(
    cpf varchar(11) PRIMARY KEY,
    nome text,
    data_nascimento date,
    nacionalidade text,
    sexo text,
    estado_civil text,
    rg varchar(7) UNIQUE,
    data_admissao date,
    endereco text,
    telefone int
);

CREATE TABLE cargo_ocupado(
    id SERIAL PRIMARY KEY,
    cargo text,
    dt_inicio date,
    dt_fim date,
    cargo_funcionario varchar(11) REFERENCES funcionario (cpf)

);

CREATE TABLE dependentes(
    id SERIAL PRIMARY KEY,
    nome text,
    dt_nascimento date,
    dependente_funcionario varchar(11) REFERENCES funcionario(cpf)
);