DROP DATABASE IF EXISTS clinica2;
CREATE DATABASE clinica2;

\c clinica2;

CREATE TABLE paciente(
    id SERIAL PRIMARY KEY ,
    nome text,
    data_nascimento date,
    sexo text,
    convenio text,
    estado_civil text,
    rg varchar(7),
    endereco text,
    telefone int
);

CREATE TABLE medico(
    crm_medico varchar(5) PRIMARY KEY,
    nome text
);

CREATE TABLE exame(
    id SERIAL PRIMARY KEY,
    exame text,
    data date,
    exame_paciente integer REFERENCES paciente(id)
);

CREATE TABLE consulta(
    id_consulta SERIAL PRIMARY KEY UNIQUE,
    data date,
    diagnostico text,
    id_paciente integer REFERENCES paciente(id),
    id_medico varchar(5) REFERENCES medico (crm_medico)

);

--INSERT INTO ficha (nome, sexo, convenio, estado_civil, rg, endereco, telefone) VALUES ('fulana', 'feminino', 'unimed', 'casada', '1112111', 'cdn', 123456789);

--INSERT INTO ficha (nome, sexo, convenio, estado_civil, rg, endereco, telefone) VALUES ('ciclana', 'feminino', 'tururu', 'casada', '2222222', 'cdn', 123456339);

--insert into medico (crm_medico, nome) values ('22222','luiz');

CREATE USER fulano3 WITH PASSWORD 'fulano3' SUPERUSER;
GRANT ALL PRIVILEGES ON DATABASE clinica TO fulano3;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO fulano3;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO fulano3;


CREATE USER beltrano WITH PASSWORD 'beltrano' CREATEDB;
GRANT SELECT ON ALL TABLES IN SCHEMA public to beltrano;



