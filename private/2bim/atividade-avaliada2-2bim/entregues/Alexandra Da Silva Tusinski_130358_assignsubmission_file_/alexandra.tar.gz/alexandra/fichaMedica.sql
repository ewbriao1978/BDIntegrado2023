DROP DATABASE IF EXISTS fichaMedica;
create database fichaMedica;

\c fichaMedica;

DROP TABLE IF EXISTS  exame;
DROP TABLE IF EXISTS  consulta;
DROP TABLE IF EXISTS  medico;
DROP TABLE IF EXISTS  convenio;
DROP TABLE IF EXISTS  paciente;

 create table paciente(
     id serial primary key,
     nome text,
     dataNascimento date,
     sexo text,
     estadoCivil text,
     rg varchar(10),
     telefone text,
     endereco text,
     CONSTRAINT id_UNIQUE UNIQUE (id)
 );

 create table convenio(
     id serial primary key,
     nome text,
     endereco text,
     telefone text
 );

  create table medico(
      crm text primary key,
      nome text,
      CONSTRAINT crm_UNIQUE UNIQUE (crm)
 );

 create table consulta(
     id serial primary key,
     data timestamp,
     diagnostico text,
     id_medico integer references medico(id),
     id_paciente integer references paciente(id),
     id_exame integer references exame(id),
     CONSTRAINT id_UNIQUE UNIQUE (id)
 );

 create table exame(
     id serial primary key,
     nome text,
     data timestamp
     id_paciente integer references paciente(id),
     crm_medico text references medico(crm),
     id_consulta integer references consulta(id) 

 );


--exercício 4)
-- criando um super usuário:

--CREATE SUPERUSER <fulano>
--WITH ENCRYPTED PASSWORD '12345';
--GRANT ALL PRIVILEGES ON DATABASE <fichaMedica>
--TO <fulano>;


--criando um usuario que pode somente consultar o bd:

--GRANT select ON DATABASE fichaMedica TO ciclano WITH ENCRYPTED PASSWORD '123';