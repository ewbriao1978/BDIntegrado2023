package Persistencia;


import java.sql.*;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Pessoa;


public class PessoaDAO {

    public Pessoa obter(int id) throws SQLException {
        Pessoa pessoa = null;
        String sqlSelect = "SELECT * FROM pessoa WHERE id = ?;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sqlSelect);
        preparedStatement.setInt(1, id);
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            pessoa = new Pessoa();
            pessoa.setId(rs.getInt("id"));
            pessoa.setNome(rs.getString("nome"));
            pessoa.setcpf(rs.getString("cpf"));
            pessoa.setestadoCivil(rs.getString("estadoCivil"));
            pessoa.setendereco(rs.getString("endereco"));
            pessoa.setnacionalidade(rs.getString("nacionalidade"));
            pessoa.setrg(rs.getString("rg"));
            pessoa.settelefone(rs.getString("telefone"));
            pessoa.setsexo(rs.getString("sexo"));
            
        }
        rs.close();
        connection.close();
        return pessoa;
    }

    public ArrayList<Pessoa> listarTodos() throws SQLException {
        String sqlSelect = "SELECT * FROM pessoa;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        ResultSet rs = connection.prepareStatement(sqlSelect).executeQuery();
        ArrayList<Pessoa> vetPessoa = new ArrayList();
        Pessoa pessoa = null;
        
        while (rs.next()) {

        	pessoa = new Pessoa();
            pessoa.setId(rs.getInt("id"));
            pessoa.setNome(rs.getString("nome"));
            pessoa.setcpf(rs.getString("cpf"));
            pessoa.setestadoCivil(rs.getString("estadoCivil"));
            pessoa.setendereco(rs.getString("endereco"));
            pessoa.setnacionalidade(rs.getString("nacionalidade"));
            pessoa.setrg(rs.getString("rg"));
            pessoa.settelefone(rs.getString("telefone"));
            pessoa.setsexo(rs.getString("sexo"));

            vetPessoa.add(pessoa);
        }
        rs.close();
        connection.close();
        return vetPessoa;
    }

    public boolean inserir(Pessoa pessoa) throws SQLException {
        boolean resultado = false;
        String sql = "INSERT INTO pessoa(nome, cpf, estado civil, endereco, nacionalidade, rg, telefone, sexo) VALUES (?, ?, ?, ?, ?, ?,?, ?, ?) RETURNING id;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, pessoa.getNome());
        preparedStatement.setString(2, pessoa.getcpf());
        preparedStatement.setString(3, pessoa.getestadoCivil());
        preparedStatement.setString(4, pessoa.getendereco());
        preparedStatement.setString(5, pessoa.getnacionalidade());
        preparedStatement.setString(6, pessoa.getrg());
        preparedStatement.setString(6, pessoa.gettelefone());
        preparedStatement.setString(6, pessoa.getsexo());
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            pessoa.setId(rs.getInt("id"));
            resultado = true;
        }
        preparedStatement.close();
        connection.close();
        return resultado;
    }