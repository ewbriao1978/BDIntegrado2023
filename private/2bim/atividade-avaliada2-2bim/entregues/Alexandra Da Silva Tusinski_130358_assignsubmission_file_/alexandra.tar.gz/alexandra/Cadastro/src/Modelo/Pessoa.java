package Modelo;

import java.util.ArrayList;


public class Pessoa {
    private int id;
    private String nome;
    private String cpf;
    private String estadoCivil;
    private String endereco;
    private String nacionalidade;
    private String rg;
    private String telefone;
    private String sexo;
    
    
   
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getcpf() {
        return cpf;
    }

    public void setecpf(String cpf) {
        this.cpf = cpf;
    }
    public String getestadoCivil() {
        return estadoCivil;
    }

    public void setestadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }
    
    public String getendereco() {
        return endereco;
    }

    public void setendereco(String endereco) {
        this.endereco = endereco;
    }
    
    public String getnacionalidade() {
        return nacionalidade;
    }

    public void setnacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }
    
    public String getrg() {
        return rg;
    }

    public void setrg(String rg) {
        this.rg = rg;
    }
    
    public String gettelefone() {
        return telefone;
    }

    public void settelefone(String telefone) {
        this.telefone = telefone;
    }
    
    public String getsexo() {
        return sexo;
    }

    public void setsexo(String sexo) {
        this.sexo = sexo;
    }
  
}
