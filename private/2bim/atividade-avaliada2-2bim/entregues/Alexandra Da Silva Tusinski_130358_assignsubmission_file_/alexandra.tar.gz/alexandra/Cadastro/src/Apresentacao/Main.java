package Apresentacao;


import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Dependente;
import modelo.Pessoa;
import persistencia.PessoaDAO;


public class Main {

    public static void main(String[] args) throws SQLException {
        pessoa p = new pessoa();
        pessoa = new pessoa();
        pessoa.setNome(rs.getString("Marcos"));
        pessoa.setcpf(rs.getString("11111111111"));
        pessoa.setestadoCivil(rs.getString("solteiro"));
        pessoa.setendereco(rs.getString("Maua 123, rg, RS"));
        pessoa.setnacionalidade(rs.getString("brasileiro"));
        pessoa.setrg(rs.getString("2222222222"));
        pessoa.settelefone(rs.getString("984757502"));
        pessoa.setsexo(rs.getString("masculino"));
        
        boolean resultado = new PessoaDAO().inserir(p);
        System.out.println("Deu certo?"+resultado);
        System.out.println("Qual id:"+p.getId());
       
    }

}