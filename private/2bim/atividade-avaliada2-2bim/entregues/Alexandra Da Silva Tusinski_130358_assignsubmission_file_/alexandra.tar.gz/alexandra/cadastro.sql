DROP DATABASE IF EXISTS cadastro;
create database cadastro;

\c cadastro;

DROP TABLE IF EXISTS  funcionarioCargo;
DROP TABLE IF EXISTS  cargo;
DROP TABLE IF EXISTS  dependente;
DROP TABLE IF EXISTS  funcionario;

create table funcionario(
    id serial primary key,
    nome text,
    cpf character(11),
    dataNascimento date,
    nascionalidade text,
    sexo text,
    estCivil text,
    rg character (10),
    dataAdm date,
    endereco text,
    telefone text,
    CONSTRAINT cpf_UNIQUE UNIQUE (cpf)

);

creat table dependente(
    id serial primary key,
    nome text,
    dataNascimento timestamp,
    id_funcionario integer references funcionario(id) 
);


create table cargo(
    id serial primary key,
    cargo text
);

create table funcionarioCargo(
    id serial primary key,
    dataInicial timestamp,
    dataFinal timestamp
    id_funcionario integer references funcionario(id),
    id_ cargo integer references cargo(id)

);

