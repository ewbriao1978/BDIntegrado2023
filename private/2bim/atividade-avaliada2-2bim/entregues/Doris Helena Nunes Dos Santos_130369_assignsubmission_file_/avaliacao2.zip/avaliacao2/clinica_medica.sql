DROP DATABASE IF EXISTS clinica_medica;
CREATE DATABASE clinica_medica;

\c clinica_medica

CREATE TABLE paciente(
    id serial PRIMARY KEY,
    rg CHARACTER(10),
    nome TEXT,
    data_nascimento DATE,
    sexo CHARACTER(1),
    estado_civil TEXT,
    endereco TEXT,
    telefone CHARACTER(12)
);

CREATE TABLE convenio(
    id serial PRIMARY KEY,
    nome TEXT,
    paciente_id INTEGER REFERENCES paciente(id)
);

CREATE TABLE medico(
    id serial PRIMARY KEY,
    crm CHARACTER(7),
    nome TEXT
);

CREATE TABLE consultas(
    id serial PRIMARY KEY,
    consulta_numero INTEGER UNIQUE,
    data DATE,
    crm CHARACTER(7)UNIQUE,
    diagnostico TEXT,
    medico_id INTEGER REFERENCES medico(id),
    paciente_id INTEGER REFERENCES paciente(id)
);

CREATE TABLE exames(
    id serial PRIMARY KEY,
    exame_numero INTEGER UNIQUE,
    descricao TEXT,
    data DATE,
    paciente_id INTEGER REFERENCES paciente(id)
);

CREATE TABLE ficha_paciente(
    id serial PRIMARY KEY,
    paciente_id INTEGER REFERENCES paciente(id),
    medico_id INTEGER REFERENCES medico(id)
);


INSERT INTO paciente(rg,nome,data_nascimento,sexo,estado_civil,endereco,telefone)  VALUES('1111111111','Angela Rodrigues','1989-06-25','f','solteira','Amazonas,13,Rural','539999999999');
INSERT INTO convenio(nome,paciente_id) VALUES('Unimed',1);
INSERT INTO medico(crm,nome) VALUES('1s2r348','João Augusto Santos');
INSERT INTO consultas(consulta_numero,data,crm,diagnostico, medico_id,paciente_id) VALUES(1,'2022-06-27','1s2r348','covid',1,1);
INSERT INTO exames(exame_numero,descricao,data,paciente_id) VALUES(1,'teste de covid','2022-06-10',1);
INSERT INTO ficha_paciente(paciente_id,medico_id)VALUES(1,1);

