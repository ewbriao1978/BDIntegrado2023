DROP DATABASE IF EXISTS funcionario;
CREATE DATABASE funcionario;

\c funcionario



CREATE TABLE dados_funcionario(
    id serial PRIMARY KEY,
    cpf CHARACTER(11) UNIQUE,
    rg CHARACTER(10),
    nome TEXT,
    data_nascimento DATE,
    sexo CHARACTER(1),
    nacionalidade TEXT, 
    est_civil TEXT,
    endereco TEXT,
    telefone CHARACTER(12),
    data_admissao date
);
CREATE TABLE cargos_ocupados(
    id serial PRIMARY KEY,
    cargo TEXT,
    data_inicio DATE,
    data_fim DATE,
    dados_funcionario_id integer REFERENCES dados_funcionario(id)
);

CREATE TABLE dependentes(
    id serial PRIMARY KEY,
    nome TEXT,
    data_nascimento DATE,
    dados_funcionario_id integer REFERENCES dados_funcionario(id)
);

INSERT INTO dados_funcionario(cpf,rg,nome,data_nascimento,sexo,nacionalidade,est_civil,endereco,telefone,data_admissao) VALUES('11111111111','1112221122','Amelia Santos','1989-05-01','f','brasileira','solteira','Republica,123,buchholz','53991919191','2000-03-01');
INSERT INTO dados_funcionario
    (cpf,rg,nome,data_nascimento,sexo,nacionalidade,est_civil,endereco,telefone,data_admissao)
VALUES('10000000000', '1112221123', 'Marcos Dutra', '1974-04-04', 'm', 'brasileiro', 'casado', 'Nicaragua,123,buchholz', '53933919191', '2003-01-01');
INSERT INTO dados_funcionario
    (cpf,rg,nome,data_nascimento,sexo,nacionalidade,est_civil,endereco,telefone,data_admissao)
VALUES('12222222222', '1113321122', 'Ricardo Oliveira', '1995-12-18', 'f', 'brasileiro', 'divorciado', 'Amapá,52,buchholz', '53991919771', '2010-07-01');
INSERT INTO dados_funcionario
    (cpf,rg,nome,data_nascimento,sexo,nacionalidade,est_civil,endereco,telefone,data_admissao)
VALUES('13333333333', '1512221622', 'Juliana Paes', '1999-11-11', 'f', 'brasileira', 'solteira', 'Avenida Brasil,33,Cassino', '53991918991', '2021-01-01');
INSERT INTO dados_funcionario
    (cpf,rg,nome,data_nascimento,sexo,nacionalidade,est_civil,endereco,telefone,data_admissao)
VALUES('1444444444', '1111521122', 'João Vicente', '1969-10-02', 'm', 'brasileiro', 'viuvo', 'Bento Goncalves,593,Cidade Nova', '53811919191', '1995-05-01');


INSERT INTO cargos_ocupados(cargo,data_inicio,data_fim, dados_funcionario_id) VALUES('almoxarifado','2000-03-01','2005-06-10',1);
INSERT INTO cargos_ocupados(cargo,data_inicio,data_fim, dados_funcionario_id)VALUES('vendedora', '2003-01-01', '2019-08-07', 4);
INSERT INTO cargos_ocupados(cargo,data_inicio,data_fim, dados_funcionario_id)VALUES('vendedor', '2021-01-01', '2022-07-27', 2);
INSERT INTO cargos_ocupados(cargo,data_inicio,data_fim, dados_funcionario_id)VALUES('caixa', '1995-05-01', '1996-05-01', 5);
INSERT INTO cargos_ocupados(cargo,data_inicio,data_fim, dados_funcionario_id)VALUES('vendedor', '1996-05-02', '1998-05-01', 5);
INSERT INTO cargos_ocupados(cargo,data_inicio,data_fim, dados_funcionario_id)VALUES('supervisor de vendas', '1998-05-02', '2022-07-07', 5);

INSERT INTO dependentes(nome,data_nascimento,dados_funcionario_id)VALUES('Julia Santos','2010-06-01',1);
INSERT INTO dependentes(nome,data_nascimento,dados_funcionario_id)VALUES('João Dutra', '1999-12-28', 2);
INSERT INTO dependentes(nome,data_nascimento,dados_funcionario_id)VALUES('Pedro Dutra', '1999-12-28', 2);
INSERT INTO dependentes(nome,data_nascimento,dados_funcionario_id)VALUES('Camila Dutra', '2000-02-15', 2);
INSERT INTO dependentes(nome,data_nascimento,dados_funcionario_id)VALUES('Andressa Vicente', '2010-09-15', 5);