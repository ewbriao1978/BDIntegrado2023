/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.util.ArrayList;
import negocio.Pessoa;
import java.sql.*;

/**
 *
 * @author iapereira
 */
public class FuncionarioDAO {

    public ArrayList<Funcionario> listar() throws SQLException {
        ArrayList<Funcionario> vetFuncionario = new ArrayList();
        String sql = "SELECT * FROM funcionario";
        Connection connection = new ConexaoPostgreSQL().getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet rs = preparedStatement.executeQuery();
        Funcionario f = null;
        while (rs.next()) {
            f = new Funcionario();
            f.setId(rs.getInt("id"));
            f.setCpf(rs.getString("nome"));
            f.setNome(rs.getString("cpf"));
            f.setNome(rs.getString("nacionalidade"));
            f.setNome(rs.getString("sexo"));
            f.setNome(rs.getString("est_civil"));
            f.setNome(rs.getString("rg"));
            f.setNome(rs.getString("endereco"));
            f.setNome(rs.getString("telefone"));
            vetFuncionario.add(f);
        }
        preparedStatement.close();
        connection.close();
        return vetFuncionario;
    }

    public void inserir(Funcionario f) throws SQLException {
        String sql = "INSERT INTO funcionario (nome,cpf,nacionalidade,sexo,est_civil,rg,endereco,telefone) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        Connection connection = new ConexaoPostgreSQL().getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, f.getNome());
        preparedStatement.setString(2, f.getCpf());
        preparedStatement.setString(2, f.getNacionalidade());
        preparedStatement.setString(2, f.getSexo());
        preparedStatement.setString(2, f.getEst_civil());
        preparedStatement.setString(2, f.getRg());
        preparedStatement.setString(2, f.getEndereco());
        preparedStatement.setString(2, f.getTelefone());
        preparedStatement.execute();
        preparedStatement.close();
        connection.close();
    }

    public void excluir(String id) throws SQLException {
        String sql = "DELETE FROM funcionario WHERE id = ?;";
        Connection connection = new ConexaoPostgreSQL().getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, id);
        preparedStatement.execute();
        preparedStatement.close();
        connection.close();
    }

    public void atualizar(Pessoa p) throws SQLException {
        String sql = "UPDATE funcionario SET nome = ? WHERE cpf = ?;";
        Connection connection = new ConexaoPostgreSQL().getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, p.getNome());
        preparedStatement.setString(2, p.getCpf());
        preparedStatement.execute();
        preparedStatement.close();
        connection.close();
    }
    
}