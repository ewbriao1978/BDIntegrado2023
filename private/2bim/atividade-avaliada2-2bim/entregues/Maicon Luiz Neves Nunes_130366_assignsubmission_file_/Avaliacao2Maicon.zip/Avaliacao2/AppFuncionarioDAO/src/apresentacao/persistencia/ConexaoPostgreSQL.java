


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import static java.util.logging.Logger.getLogger;

/**
 *
 * @author iapereira
 */

import java.sql.*;
import java.util.logging.Level;

public class ConexaoPostgreSQL {
    private String host;
    private String port;
    private String username;
    private String password;
    private String database;

    public ConexaoPostgreSQL() {
        this.host = "localhost";
        this.port = "5432";
        this.username = "postgres";
        this.password = "postgres";
        this.database = "dao";
    }

    public Connection getConnection() {
        String url = "jdbc:postgresql://" + this.host + ":" + this.port + "/" + this.database;
        System.out.println("=================================================================");
        try {
            String x = "concluido com sucesso!";

            System.out.println("=================================================================");
            return DriverManager.getConnection(url, username, password);
        } catch (SQLException ex) {
            System.out.println("error na conexao!!");
            System.out.println("=================================================================");
            getLogger(ConexaoPostgreSQL.class.getName()).log(Level.SEVERE, null, ex);
    System.out.println("=================================================================");             
    }
    return null;
    }
    
}