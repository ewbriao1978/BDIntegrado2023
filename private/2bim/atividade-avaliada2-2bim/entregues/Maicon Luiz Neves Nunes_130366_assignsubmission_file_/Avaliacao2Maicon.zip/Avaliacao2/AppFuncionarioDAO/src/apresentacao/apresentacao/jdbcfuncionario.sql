DROP DATABASE IF EXISTS jdbcfuncionario;

CREATE DATABASE jdbcfuncionario;

\c jdbcfuncionario;

create table funcionario (
    id serial primary key,
    nome text,
    cpf CHARACTER(11) unique,
    nacionalidade text,
    sexo character(1),
    est_civil text,
    rg text,
    endereco text, 
    telefone text
);

insert into funcionario(nome,cpf,nacionalidade,sexo,est_civil,rg, endereco,telefone)
values ('Mauricio', '11111111111','Brasileiro','M','Solteiro','1008000222','Rua J, nr 25 - Parque Solar','53-991919191');

