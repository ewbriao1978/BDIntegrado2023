package apresentacao;

import java.sql.SQLException;
//import java.util.ArrayList;
//import negocio.Pessoa;
import persistencia.ConexaoPostgreSQL;
//import persistencia.PessoaDAO;

/**
 *
 * @author iapereira
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws SQLException {

        System.out.println("=============================================================");
        System.out.println("APRENDENDO DAO E JDBC");
        System.out.println("=============================================================");

        ConexaoPostgreSQL conexao = new ConexaoPostgreSQL();
        conexao.getConnection();

        /*

        new FuncionarioDAO().inserir(new Funcionario("Marcia Jorgina","66666666666","Brasileiro","F","solteira","03006000987","Rua Bromelias - 25","53-991828282"));


        ArrayList<Funcionario> vetFuncionario = new FuncionarioDAO().listar();               
        for (int i = 0; i < vetFuncionario.size(); i++) {
            Funcionario f = vetFuncionario.get(i);
            System.out.println("Nome:"+f.getNome());

        }
        */
    }
    
}