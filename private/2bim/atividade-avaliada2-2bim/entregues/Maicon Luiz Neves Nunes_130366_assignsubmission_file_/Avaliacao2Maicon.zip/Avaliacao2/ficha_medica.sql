DROP DATABASE IF EXISTS ficha_medica;

create database ficha_medica;


\c ficha_medica;

REVOKE ALL PRIVILEGES ON DATABASE ficha_medica FROM fulano;
DROP USER fulano;
REVOKE ALL PRIVILEGES ON DATABASE ficha_medica FROM ciclano;
DROP USER ciclano;


CREATE USER fulano WITH PASSWORD 'fulano' SUPERUSER;
GRANT ALL PRIVILEGES ON DATABASE ficha_medica TO fulano;

CREATE USER ciclano WITH PASSWORD 'ciclano';
GRANT SELECT ON ALL TABLES IN SCHEMA public to ciclano;



create table paciente(
    numero_paciente serial primary key UNIQUE,
    nome text,
    data_nasc date,
    sexo character(1),
    est_civil text,
    rg text,
    telefone text,
    endereco text
);

create table convenio(
    id serial primary key,
    nome_convenio text,
    id_paciente integer references paciente(numero_paciente)
);

 create table medico(
    id serial primary key UNIQUE,
    nome text,
    medico_CRM text
 );

create table consulta(
    numero_consulta serial primary key UNIQUE,
    data date,
    diagnostico text,
    id_convenio integer references convenio(id),
    id_medico integer references medico(id),
    id_paciente integer references paciente(numero_paciente)
);

create table exame(
    id serial primary key UNIQUE,
    exame text,
    data date,
    id_paciente integer references paciente(numero_paciente),
    id_consulta integer references consulta(numero_consulta)
);

insert into paciente(nome,data_nasc,sexo,est_civil,rg,telefone,endereco) values('Mauro','2000-11-09','M','Solteiro','2020900222','53-991917441','Rua Acasia, 2115 - Pelotas');
insert into paciente(nome,data_nasc,sexo,est_civil,rg,telefone,endereco) values('Cezar','2001-12-09','M','Casado','1010900222','53-981917441','Rua Acaraje, 21 - Centro - pelotas');
insert into paciente(nome,data_nasc,sexo,est_civil,rg,telefone,endereco) values('Mauricio','2007-08-24','M','Solteiro','202090333','53-991917881','Rua Amauri, 2 - Navegantes - Pelotas');
insert into paciente(nome,data_nasc,sexo,est_civil,rg,telefone,endereco) values('Roberta','2000-12-10','F','Solteira','2020888222','53-999917441','Rua Assembleia, 15A - Pelotas - Jardim Perez');
insert into paciente(nome,data_nasc,sexo,est_civil,rg,telefone,endereco) values('Maurem','2021-11-11','F','Solteira','2020900999','53-991917557','Rua Monte Carlo, 2B - Pelotas - Santa Tereza');

insert into convenio(nome_convenio, id_paciente) values ('unimed',1);
insert into convenio(nome_convenio, id_paciente) values ('uniclinica',2);
insert into convenio(nome_convenio, id_paciente) values ('policlinica',3);
insert into convenio(nome_convenio, id_paciente) values ('centroclinico',4);
insert into convenio(nome_convenio, id_paciente) values ('SUS',5);

insert into medico(nome, medico_CRM) values('Rafael Jr','253MH');
insert into medico(nome, medico_CRM) values('Souza Jr','255HH');
insert into medico(nome, medico_CRM) values('Marta Medeiros','111AA');
insert into medico(nome, medico_CRM) values('Raul Gazola','741XX');
insert into medico(nome, medico_CRM) values('Ivania','852PP');
insert into medico(nome, medico_CRM) values('Ilda Costa','279MM');

insert into consulta(data, diagnostico,id_convenio,id_medico,id_paciente)values('2021-01-03', 'falta de ar',2,1,1);
insert into consulta(data, diagnostico,id_convenio,id_medico,id_paciente)values('2021-02-13', 'fazer exame',1,3,2);
insert into consulta(data, diagnostico,id_convenio,id_medico,id_paciente)values('2021-03-23', 'dor de cabeca',1,2,1);
insert into consulta(data, diagnostico,id_convenio,id_medico,id_paciente)values('2021-04-09', 'fazer exame',2,5,4);
insert into consulta(data, diagnostico,id_convenio,id_medico,id_paciente)values('2021-05-02', 'dor de garganta',5,4,5);

insert into exame (exame,data,id_paciente,id_consulta)values('raio x torax','2021-01-04',1,1);
insert into exame (exame,data,id_paciente,id_consulta)values('eletrocardiograma','2021-02-14',2,2);
insert into exame (exame,data,id_paciente,id_consulta)values('raio x torax','2021-04-14',3,5);







