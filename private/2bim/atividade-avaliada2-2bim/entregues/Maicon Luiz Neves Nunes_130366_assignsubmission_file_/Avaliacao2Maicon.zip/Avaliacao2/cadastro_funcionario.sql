DROP DATABASE IF EXISTS cadastro_funcionario;

create database cadastro_funcionario;

\c cadastro_funcionario;

create table funcionario (
    id serial primary key,
    nome text,
    cpf CHARACTER(11) unique,
    data_de_nasc date,
    nacionalidade text,
    sexo character(1),
    est_civil text,
    rg text,
    data_admissao date,
    endereco text, 
    telefone text
);


create table dependente (
    id serial primary key,
    nome text,
    data_nasc date,
    funcionario_id integer references funcionario(id)
);

create table funcionario_dependente (
    id integer primary key,
    dependente_id integer references dependente(id),
    funcionario_id integer references funcionario(id)
);

create table func_cargos_ocupados (
    id serial primary key,
    data_dl_inicio date,
    data_dl_fim date,
    funcionario_id integer references funcionario(id)
);

insert into funcionario(nome,cpf,data_de_nasc,nacionalidade,sexo,est_civil,rg,data_admissao, endereco,telefone)
values ('Mauricio', '11111111111','2000-08-19','Brasileiro','M','Solteiro','1008000222','2005-10-22','Rua J, nr 25 - Parque Solar','53-991919191');
insert into funcionario(nome,cpf,data_de_nasc,nacionalidade,sexo,est_civil,rg,data_admissao, endereco,telefone)
values ('Trapilio Matos', '22222222222','1998-07-01','Brasileiro','M','Casado','2008000222','2002-10-12','Rua P, nr 55B - Parque Polar','53-991910505');
insert into funcionario(nome,cpf,data_de_nasc,nacionalidade,sexo,est_civil,rg,data_admissao, endereco,telefone)
values ('Rodrigo Abelardo', '33333333333','1995-07-09','Uruguaio','M','Casado','1008000111','1995-11-05','Rua Z, nr 1125 - Parque Lurdes','53-999999910');
insert into funcionario(nome,cpf,data_de_nasc,nacionalidade,sexo,est_civil,rg,data_admissao, endereco,telefone)
values ('Marta Betania', '44444444444','2000-10-10','Brasileira','F','Casada','1002220222','2004-06-17','Rua Rio Pardo, nr 119 - Parque Solar','53-981919191');
insert into funcionario(nome,cpf,data_de_nasc,nacionalidade,sexo,est_civil,rg,data_admissao, endereco,telefone)
values ('Mauren Soares', '55555555555','2004-08-05','Brasileira','F','Solteira','1004545444','2010-10-10','Rua Y, nr 2578 - Parque Rosal','53-991915555');

insert into dependente (nome, data_nasc,funcionario_id) values('Mirian','2015-05-06',2);
insert into dependente (nome, data_nasc,funcionario_id) values('Vera','2014-10-11',3);
insert into dependente (nome, data_nasc,funcionario_id) values('Mauricio','2015-05-11',3);
insert into dependente (nome, data_nasc,funcionario_id) values('Joao Ribeiro','2000-07-06',4);
insert into dependente (nome, data_nasc,funcionario_id) values('Mirian','2019-12-12',4);

insert into funcionario_dependente(id, dependente_id,funcionario_id) values(1,1,2);
insert into funcionario_dependente(id, dependente_id,funcionario_id) values(2,2,3);
insert into funcionario_dependente(id, dependente_id,funcionario_id) values(3,3,3);
insert into funcionario_dependente(id, dependente_id,funcionario_id) values(4,4,4);
insert into funcionario_dependente(id, dependente_id,funcionario_id) values(5,5,4);

insert into func_cargos_ocupados(data_dl_inicio,data_dl_fim,funcionario_id)values('2018-10-05',null,1);
insert into func_cargos_ocupados(data_dl_inicio,data_dl_fim,funcionario_id)values('2012-11-01', null,2);
insert into func_cargos_ocupados(data_dl_inicio,data_dl_fim,funcionario_id)values('2008-08-22', null,3);
insert into func_cargos_ocupados(data_dl_inicio,data_dl_fim,funcionario_id)values('2004-10-05', '2021-11-05',4);
insert into func_cargos_ocupados(data_dl_inicio,data_dl_fim,funcionario_id)values('2009-04-07', null,5);

