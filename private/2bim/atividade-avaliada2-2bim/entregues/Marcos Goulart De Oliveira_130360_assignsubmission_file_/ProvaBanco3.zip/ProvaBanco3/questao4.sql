create user fulano with password 'fulano' superuser;
grant all privileges on database questao3 to fulano;

create user ciclano with password 'ciclano';
grant select on all tables in schema public to ciclano;