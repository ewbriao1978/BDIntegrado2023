import java.sql.SQLException;

public class Main {
	public static void main(String[] args) throws SQLException {
		Funcionario funcionario = new Funcionario("87356104091", "Marcos", "Solteiro", "avenida bla 123", 
				"brasileiro", "91654654", "991978098", "M");
		FuncionarioDao funcionarioDao = new FuncionarioDao();
		funcionarioDao.inserir(funcionario);
	}
}
