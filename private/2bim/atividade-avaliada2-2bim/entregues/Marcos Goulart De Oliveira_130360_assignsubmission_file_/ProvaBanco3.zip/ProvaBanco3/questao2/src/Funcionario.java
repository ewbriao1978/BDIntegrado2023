

public class Funcionario {
	
	private String cpf;
	private String nome;
	private String estadoCivil;
	private String endereco;
	private String nacionalidade;
	private String rg;
	private String telefone;
	private String sexo;

	public Funcionario(String cpf, String nome, String estadoCivil, String endereco, String nacionalidade, String rg,String telefone, String sexo) {
		this.cpf = cpf;
		this.nome = nome;
		this.estadoCivil = estadoCivil;
		this.endereco = endereco;
		this.nacionalidade = nacionalidade;
		this.rg = rg;
		this.telefone = telefone;
		this.sexo = sexo;
	}
	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
}
