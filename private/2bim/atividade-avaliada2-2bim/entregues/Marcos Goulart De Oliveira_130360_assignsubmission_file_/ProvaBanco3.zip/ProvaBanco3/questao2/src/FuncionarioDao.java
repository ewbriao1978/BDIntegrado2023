import java.sql.*;
import java.sql.ResultSet;

public class FuncionarioDao {
	public boolean inserir(Funcionario funcionario) throws SQLException {        
        String sql = "insert into funcionario(cpf, nome, estado_civil, endereco, nacionalidade, rg, telefone, sexo) values(?,?,?,?,?,?,?,?);";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, funcionario.getCpf());
        preparedStatement.setString(2, funcionario.getNome());
        preparedStatement.setString(3, funcionario.getEstadoCivil());
        preparedStatement.setString(4, funcionario.getEndereco());
        preparedStatement.setString(5, funcionario.getNacionalidade());
        preparedStatement.setString(6, funcionario.getRg());
        preparedStatement.setString(7, funcionario.getTelefone());
        preparedStatement.setString(8, funcionario.getSexo());
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return (resultado == 1);
    }
}
