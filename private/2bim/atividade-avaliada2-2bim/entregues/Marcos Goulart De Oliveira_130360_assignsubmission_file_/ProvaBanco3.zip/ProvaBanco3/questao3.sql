drop database if exists questao2;
create database questao2;

drop table if exists exame;
drop table if exists consulta;
drop table if exists medico;
drop table if exists paciente;
drop table if exists convenio;

create table convenio(
    id serial primary key,
    nome text
);

create table paciente(
    numero text not null primary key,
    nome text,
    data_nascimento date,
    sexo text,
    id_convenio integer references convenio(id),
    estado_civil text,
    rg text,
    telefone text,
    endereco text
);

create table medico(
    crm text not null primary key,
    nome text
);

create table consulta (
    numero text not null primary key,
    numero_paciente text references paciente(numero),
    data date,
    crm_medico text references medico(crm),
    diagnostico text
);

create table exame(
    id serial primary key,
    numero_consulta text references consulta(numero),
    exame text,
    data date
);