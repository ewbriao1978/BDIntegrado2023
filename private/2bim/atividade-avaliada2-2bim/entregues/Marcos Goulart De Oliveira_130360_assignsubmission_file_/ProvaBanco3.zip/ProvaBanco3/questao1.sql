drop database if exists questao1;
create database questao1;

drop table if exists dependente;
drop table if exists ocupacao;
drop table if exists cargo;
drop table if exists funcionario;

create table funcionario(
    cpf text not null primary key unique,
    nome text not null,
    data_nascimento date,
    nacionalidade text not null,
    sexo text not null,
    estado_civil text not null,
    rg text not null,
    endereco text not null,
    telefone text not null
);

create table cargo(
    id serial primary key,
    nome text not null
);

create table ocupacao(
    id serial primary key,
    cpf_funcionario text not null references funcionario(cpf),
    id_cargo integer not null references cargo(id),
    data_inicio date,
    data_fim date
);

create table dependente(
    id serial primary key,
    cpf_funcionario text not null references funcionario(cpf),
    nome text,
    data_nascimento date
);