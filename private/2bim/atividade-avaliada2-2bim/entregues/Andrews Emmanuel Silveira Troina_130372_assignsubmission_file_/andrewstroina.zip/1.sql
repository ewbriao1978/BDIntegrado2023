-- psql -U postgres
-- só pra fixar
-- 1.
DROP DATABASE IF EXISTS cadastro;

CREATE DATABASE cadastro;


\c cadastro;

CREATE TABLE funcionario (
    id SERIAL PRIMARY KEY,
    cpf CHARACTER(11) UNIQUE,
    nome TEXT NOT NULL,
    data_nasc DATE,
    est_civil TEXT,
    endereco TEXT,
    nacionalidade TEXT,
    rg CHARACTER(10),
    telefone TEXT,
    sexo CHARACTER(1),
    data_adimissao DATE
);

CREATE TABLE cargos (
    id SERIAL PRIMARY KEY,
    nome_cargo TEXT
);

CREATE TABLE ocupacao (
    id SERIAL PRIMARY KEY,
    data_inicio DATE,
    data_fim DATE,
    cargo_id INTEGER REFERENCES cargos (id),
    funcionario_id INTEGER REFERENCES funcionario (id)
);

CREATE TABLE dependentes (
    id SERIAL PRIMARY KEY,
    nome TEXT NOT NULL,
    data_nasc DATE,
    funcionario_id INTEGER REFERENCES funcionario (id)
);

---------------------------------------------------------- INSERTS para teste

INSERT INTO funcionario (cpf, nome, data_nasc, est_civil, endereco, nacionalidade, rg, telefone, sexo, data_adimissao) VALUES
('11111111111', 'Amelia','14-12-1954', 'casada',   'parque marinha ',  'brasileira', '1111111111', '(53) 99999999', 'f', '01-01-2000'),
('22222222222', 'Marla', '19-05-1985', 'casada',   'centro',           'brasileira', '2222222222', '(53) 88888888', 'm', '01-01-2000'),
('33333333333', 'Tadeu', '21-06-1949', 'casado',   'parque sao pedro', 'brasileiro', '3333333333', '(53) 77777777', 'f', '01-01-2000'),
('44444444444', 'Yasmin','15-10-2009', 'solteira', 'cassino',          'brasileira', '4444444444', '(53) 66666666', 'f', '01-01-2020');

INSERT INTO cargos (nome_cargo) VALUES
('ceo'),
('gerente'),
('dono'),
('estagiario');

INSERT INTO ocupacao (cargo_id, data_inicio, data_fim, funcionario_id) VALUES
(1, '01-01-2000', '01-01-2020', 1),
(2, '01-01-2000', '01-01-2021', 2),
(1, '01-01-2000', '01-01-2015', 3),
(3, '01-01-2020', '01-01-2001', 3),
(4, '01-01-2020', '01-01-2022', 4);

INSERT INTO dependentes (nome, data_nasc, funcionario_id) VALUES
('Andrews', '01-01-2000', 1),
('Hanry',   '01-01-2000', 2),
('Marla',   '01-01-2000', 3),
('Yasmin',  '01-01-2020', 2);
