/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import java.sql.*;
import java.sql.ResultSet;
import java.util.ArrayList;
import modelo.Funcionario;


/**
 *
 * @author iapereira
 */
public class FuncionarioDAO {

    public Funcionario obter(int id) throws SQLException {
        String sqlSelect = "select funcionario.cpf as funcionario_cpf, funcionario.nome as funcionario_nome, funcionario.est_ivil as pessoa_estadoCivil, funcionario.endereco as funcionario_endereco,funcionario.nacionalidade as funcionario_nacionalidade,funcionario.rg as funcionario_rg,funcionario.telefone as funcionario_telefone,funcionario.sexo as funcionario_sexo from funcionario where funcionario.id = ?;";
        
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sqlSelect);
        preparedStatement.setInt(1, id);
        ResultSet rs = preparedStatement.executeQuery();
        Funcionario funcionario = new Funcionario();
        
        while (rs.next()) {
            funcionario.setCpf(rs.getString("funcionario_cpf"));
            funcionario.setNome(rs.getString("funcionario_nome"));
            funcionario.setEstadoCivil(rs.getString("funcionario_estadoCivil"));
            funcionario.setEndereco(rs.getString("funcionario_endereco"));
            funcionario.setNacionalidade(rs.getString("funcionario_nacionalidade"));
            funcionario.setRg(rs.getString("funcionario_rg"));
            funcionario.setTelefone(rs.getString("funcionario_telefone"));
            funcionario.setSexo(rs.getString("funcionario_sexo"));
        }
        rs.close();
        connection.close();
        return funcionario;
    }
    
    public ArrayList<Funcionario> listarTodos() throws SQLException {
        String sqlSelect = "SELECT * FROM funcionario;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        ResultSet rs = connection.prepareStatement(sqlSelect).executeQuery();
        ArrayList<Funcionario> vetFuncionario = new ArrayList();
        Funcionario funcionario = null;
        while (rs.next()) {
            funcionario = new Funcionario();
            funcionario.setCpf(rs.getString("funcionario_cpf"));
            funcionario.setNome(rs.getString("funcionario_nome"));
            funcionario.setEstadoCivil(rs.getString("funcionario_estadoCivil"));
            funcionario.setEndereco(rs.getString("funcionario_endereco"));
            funcionario.setNacionalidade(rs.getString("funcionario_nacionalidade"));
            funcionario.setRg(rs.getString("funcionario_rg"));
            funcionario.setTelefone(rs.getString("funcionario_telefone"));
            funcionario.setSexo(rs.getString("funcionario_sexo"));
            vetFuncionario.add(funcionario);
        }
        rs.close();
        connection.close();
        
        return vetFuncionario;
    }}
    
    
/* TENHO HORARIO PARA PEGAR O BUSAO :(

    public boolean inserir(Funcionario pessoa) throws SQLException {
        boolean resultado = false;
        String sql = "INSERT INTO funcionario(nome, sobrenome) VALUES (?, ?) RETURNING id;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, pessoa.getNome());
        preparedStatement.setString(2, pessoa.getSobrenome());
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            pessoa.setId(rs.getInt("id"));
            resultado = true;
        }
        preparedStatement.close();
        connection.close();
        return resultado;
    }

    public boolean excluir(int id) throws SQLException {
        String sql = "DELETE FROM pessoa WHERE id = ?;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, id);
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return (resultado == 1);
    }

   
    public boolean atualizar(Pessoa pessoa) throws SQLException {
        String sql = "UPDATE pessoa SET nome = ?, sobrenome = ? WHERE id = ?;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, pessoa.getNome());
        preparedStatement.setString(2, pessoa.getSobrenome());
        preparedStatement.setInt(3, pessoa.getId());
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return (resultado == 1);
    }
}
*/