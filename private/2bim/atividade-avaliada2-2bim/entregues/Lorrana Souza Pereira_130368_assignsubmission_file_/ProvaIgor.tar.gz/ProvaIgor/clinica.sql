DROP DATABASE IF EXISTS dbclinica;
CREATE DATABASE dbclinica;

\c dbclinica;

CREATE TABLE convenio (
    id SERIAL primary key,
    nome varchar(50)
);
CREATE TABLE paciente (
    id SERIAL primary key,
    nome VARCHAR(100) NOT NULL,
    data_nascimento date,
    id_convenio integer,
    sexo char(1) NOT NULL,
    endereco text NOT NULL,
    rg character(10) NOT NULL,
    telefone text NOT NULL,
    est_civil varchar(10) NOT NULL,
    CONSTRAINT Check_sexo CHECK (sexo in ('F','M')),
    CONSTRAINT FK_convenio FOREIGN KEY (id_convenio)
        REFERENCES  convenio (id) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE medico (
    crm text primary key,
    nome VARCHAR(50)
);

CREATE TABLE consulta (
    crm_medico text,
    id_paciente integer,
    data date,
    diagnostico text,
    primary key(crm_medico, id_paciente),
    CONSTRAINT FK_crm_medico FOREIGN KEY (crm_medico)
        REFERENCES  medico (crm) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT FK_paciente FOREIGN KEY (id_paciente)
        REFERENCES  paciente (id) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE exame (
    id serial primary key,
    nome text
);

CREATE TABLE pacienteExame (
    id_paciente integer,
    id_exame integer,
    CONSTRAINT FK_paciente_exame FOREIGN KEY (id_paciente)
        REFERENCES  paciente (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT FK_exame FOREIGN KEY (id_exame)
        REFERENCES  exame (id) ON DELETE SET NULL ON UPDATE CASCADE
);

INSERT INTO medico (crm,nome) VALUES('1548899','Maicon');
--------- 4 

REVOKE ALL PRIVILEGES ON DATABASE dbclinica FROM fulano;
DROP USER fulano;
REVOKE ALL PRIVILEGES ON DATABASE dbclinica FROM ciclano;
DROP USER ciclano;

CREATE USER fulano WITH PASSWORD 'fulano' SUPERUSER;
GRANT ALL PRIVILEGES ON DATABASE dbclinica TO fulano;

CREATE USER ciclano WITH PASSWORD 'ciclano';
GRANT SELECT ON ALL TABLES IN SCHEMA public to ciclano;
