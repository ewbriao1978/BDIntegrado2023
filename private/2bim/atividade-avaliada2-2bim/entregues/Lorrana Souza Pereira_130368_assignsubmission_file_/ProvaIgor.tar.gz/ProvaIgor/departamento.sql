DROP DATABASE IF EXISTS dbdepartamento;
CREATE DATABASE dbdepartamento;

\c dbdepartamento;
-- DROP TABLE IF EXISTS funcionario;
-- DROP TABLE IF EXISTS cargo;
-- DROP TABLE IF EXISTS funcionario_cargo;
-- DROP TABLE IF EXISTS dependentes;

-- script construção do banc-- endereço texto simples
-- inserir banco de dados

CREATE TABLE funcionario (
    id SERIAL primary key,
    nome VARCHAR(100) NOT NULL,
    CPF VARCHAR(11) NOT NULL,
    data_nascimento date,
    sexo char(1) NOT NULL,
    est_civil varchar(10) NOT NULL,
    endereco text NOT NULL,
    nacionalidade text,
    rg character(10) NOT NULL,
    telefone text NOT NULL,
    data_admissao date,
    CONSTRAINT Check_sexo CHECK (sexo in ('F','M')),
    CONSTRAINT CPF_funcionario_UNIQUE UNIQUE (CPF)
);

CREATE TABLE cargo (
    id SERIAL primary key,
    nome VARCHAR(50)
);

CREATE TABLE funcionario_cargo (
    id_funcionario integer,
    id_cargo integer,
    data_inicio date,
    data_fim date,
    primary key (id_funcionario,id_cargo),
    CONSTRAINT FK_funcionario FOREIGN KEY (id_funcionario)
        REFERENCES  funcionario (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_cargo FOREIGN KEY (id_cargo)
        REFERENCES  cargo (id) ON DELETE SET NULL ON UPDATE CASCADE
);


CREATE TABLE dependentes (
    id SERIAL primary key,
    id_funcionario integer NOT NULL,
    nome VARCHAR(100) NOT NULL,
    data_nascimento date,
    CONSTRAINT FK_funcionario_dependente FOREIGN KEY (id_funcionario)
        REFERENCES  funcionario (id) ON DELETE CASCADE ON UPDATE CASCADE


);


INSERT INTO funcionario (cpf, nome,est_civil, endereco, nacionalidade, rg, telefone, sexo)
VALUES ('03791582055', 'BRENDA PEREIRA','casado(a)','Rua moinhos 879, bairro São joão', 'brasileiro(a)', '5128268744','53999703274', 'F');

INSERT INTO funcionario (cpf, nome,est_civil, endereco, nacionalidade, rg, telefone, sexo)
VALUES ('03791582045', 'CARLOS FERNANDES','casado(a)','Rua general bohem 568, Bairro São Miguel', 'brasileiro(a)', '7898268744','53999703280', 'M'); 
--inivio no cstho, exames tbm mesma coisa
INSERT INTO cargo (nome) VALUES ('MÉDICO');
INSERT INTO cargo (nome) VALUES ('INFERMEIRA');
INSERT INTO cargo (nome) VALUES ('SERVIÇO GERAIS');
INSERT INTO dependentes (nome, id_funcionario, data_nascimento) VALUES ('Ana Pereira',1,'2009-06-04');
INSERT INTO dependentes (nome, id_funcionario, data_nascimento) VALUES ('Carla Pereira',2,'2010-04-25');

