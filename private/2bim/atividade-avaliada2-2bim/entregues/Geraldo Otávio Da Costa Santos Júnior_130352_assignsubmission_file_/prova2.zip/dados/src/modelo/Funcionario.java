/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author iapereira
 */
public class Funcionario {
    private int id;
    private String nome;
    private String sobrenome;
    private Funcionario endereco;

    public Funcionario(int id, String nome) {
        this.id =  id;
        this.nome = nome;
    }

    public Funcionario(String nome) {
        this.nome = nome;
    }

    public Funcionario() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public Funcionario getEndereco() {
        return endereco;
    }

    public void setEndereco(Funcionario endereco) {
        this.endereco = endereco;
    }

	public Funcionario obter(int i) {
		return null;
	}
   
    
    
    
    
    
    
    
}
