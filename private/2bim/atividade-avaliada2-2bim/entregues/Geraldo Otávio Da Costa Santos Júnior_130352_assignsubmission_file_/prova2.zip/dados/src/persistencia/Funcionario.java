/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import java.sql.*;
import java.sql.ResultSet;
//import java.util.ArrayList;
//import javax.swing.JOptionPane;
//import modelo.Endereco;
//import modelo.Pessoa;

/**
 *
 * @author iapereira/gege^^
 */
public class Funcionario {

    public Funcionario obter(int id) throws SQLException {
        Funcionario funcionario = null;
        //Endereco endereco = null;
        String sqlSelect = "SELECT * FROM funcionario WHERE id = ?;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sqlSelect);
        preparedStatement.setInt(1, id);
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            extracted(funcionario).setId(rs.getInt("id"));
            extracted(funcionario).setNomF(rs.getString("nome"));
            extracted(funcionario).setSobFenome(rs.getString("sobrenome"));
        }
        rs.close();
        connection.close();
        return extracted(funcionario);
    }
    
    private Funcionario extracted(Funcionario funcionario) {
        return funcionario;
    }

    private void setSobFenome(String string) {
    }

    private void setNomF(String string) {
    }

    private void setId(int int1) {
    }

    public boolean inserir(Funcionario funcionario) throws SQLException {
        boolean resultado = false;
        String sql = "INSERT INTO funcionario(id, cpf, nome, data_nascimento, nacionalidade, sexo, estado_civil, rg, data_admissao, endereco, telefone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        Funcionario funcionario2 = funcionario;
        preparedStatement.setString(1, funcionario2.getID());
        preparedStatement.setString(2, funcionario2.getCpf());
        preparedStatement.setString(3, funcionario2.getNome());
        preparedStatement.setString(4, funcionario2.getdata_nascimento());
        preparedStatement.setString(5, funcionario2.getNacionalidade());
        preparedStatement.setString(6, funcionario2.getSexo());
        preparedStatement.setString(7, funcionario2.getEstado_civil());
        preparedStatement.setString(8, funcionario2.getRg());
        preparedStatement.setString(9, funcionario2.getData_admissao());
        preparedStatement.setString(10, funcionario2.getEndereco());
        preparedStatement.setString(11, funcionario2.getTelefone());
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            funcionario2.setId(rs.getInt("id"));
            resultado = true;
        }
        preparedStatement.close();
        connection.close();
        return resultado;
    }

    private String getTelefone() {
        return null;
    }

    private String getEndereco() {
        return null;
    }

    private String getData_admissao() {
        return null;
    }

    private String getRg() {
        return null;
    }

    private String getEstado_civil() {
        return null;
    }

    private String getSexo() {
        return null;
    }

    private String getNacionalidade() {
        return null;
    }

    private String getdata_nascimento() {
        return null;
    }

    private String getNome() {
        return null;
    }

    private String getCpf() {
        return null;
    }

    private String getID() {
        return null;
    }

    
    
}
