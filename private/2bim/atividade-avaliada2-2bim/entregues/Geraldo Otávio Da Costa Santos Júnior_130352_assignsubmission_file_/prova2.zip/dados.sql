DROP DATABASE IF EXISTS dados;
CREATE DATABASE dados;

\c dados

/*CREATE TABLE endereco(
    id integer PRIMARY KEY,
    rua text,
    numero text,
    complemento text
);*/

CREATE TABLE funcionario(
    id integer PRIMARY KEY,
    cpf varchar(11) unique,
    nome text,
    data_nascimento date,
    nacionalidade text,
    sexo char check( sexo = 'F' or sexo = 'M'),
    estado_civil text,
    rg text unique,
    data_admissao date,
    endereco text,
    telefone text
);

CREATE TABLE cargo(
    id integer PRIMARY KEY,
    cargo text,
    id_funcionario integer REFERENCES funcionario(id)
);

create table ocupacao(
    id integer primary key,
    data_inicio_cargo date,
    data_fim_cargo date,
    id_funcionario integer REFERENCES funcionario(id),
    id_cargo integer REFERENCES cargo(id)
);

CREATE TABLE dependente(
    id integer,
    nome text,
    data_nascimento date,
    id_funcionario integer REFERENCES funcionario(id) 
);

insert into funcionario(id, cpf, nome, data_nascimento, nacionalidade, sexo, estado_civil, rg,
 data_admissao, endereco, telefone) 
values(1,'11111111111', 'gege', '01-01-1991', 'nord', 'M', 'solto', '111', '01-01-2001', 'rua 1','121');
insert into funcionario(id, cpf, nome, data_nascimento, nacionalidade, sexo, estado_civil, rg,
 data_admissao, endereco, telefone) 
values(2,'22222222222', 'gaga', '02-02-1992', 'sul', 'F', 'solta', '222', '01-01-2002', 'rua 2','212');
insert into funcionario(id, cpf, nome, data_nascimento, nacionalidade, sexo, estado_civil, rg,
 data_admissao, endereco, telefone) 
values(3,'33333333333', 'gigi', '03-03-1993', 'oest', 'M', 'doido', '333', '01-01-2003', 'rua 3','313');

insert into cargo(id, cargo, id_funcionario) values (1, 'sofrido', 1);
insert into cargo(id, cargo, id_funcionario) values (2, 'quase chora', 2);
insert into cargo(id, cargo, id_funcionario) values (3, 'chorando', 3);

insert into ocupacao(id, data_inicio_cargo, data_fim_cargo, id_funcionario, id_cargo) values(1, '11-01-2001', '01-11-2001', 1, 1);
insert into ocupacao(id, data_inicio_cargo, data_fim_cargo, id_funcionario, id_cargo) values(2, '12-01-2002', '12-12-2002', 2, 2);
insert into ocupacao(id, data_inicio_cargo, data_fim_cargo, id_funcionario, id_cargo) values(3, '13-01-2003', '13-12-2003', 3, 3);

insert into dependente(id, nome, data_nascimento, id_funcionario) values (1, 'Filho 1', '01-01-2001', 1);
insert into dependente(id, nome, data_nascimento, id_funcionario) values (2, 'Filho 2', '01-02-2002', 2);
insert into dependente(id, nome, data_nascimento, id_funcionario) values (3, 'Filho 3', '01-03-2003', 3);


