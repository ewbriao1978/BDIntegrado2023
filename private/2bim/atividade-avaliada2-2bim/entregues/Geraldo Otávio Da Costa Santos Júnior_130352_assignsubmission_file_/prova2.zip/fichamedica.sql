DROP DATABASE IF EXISTS fichamedica;
CREATE DATABASE fichamedica;

\c fichamedica


CREATE TABLE endereco(
    id integer PRIMARY KEY,
    rua text,
    numero text,
    complemento text
);

CREATE TABLE medico (
    medico_crm text primary key
);

CREATE TABLE paciente(
    id integer PRIMARY KEY,
    numero_paciente text unique,
    nome text,
    data_nascimento date,
    sexo char check( sexo = 'F' or sexo = 'M'),
    estado_civil text,
    rg text unique,
    telefone text,
    id_endereco integer REFERENCES endereco(id)
);

CREATE TABLE exame(
    id integer PRIMARY KEY,
    exame text,
    data date,
    id_paciente integer REFERENCES paciente(id)
);

CREATE TABLE convenio(
    id integer,
    nome_convenio text,
    id_paciente integer REFERENCES paciente(id) 
);

CREATE TABLE consulta(
    numero_consulta text PRIMARY KEY,
    id_paciente integer REFERENCES paciente(id),
    medico_crm text REFERENCES medico(medico_crm),
    id_exame integer REFERENCES exame(id)
);

insert into endereco(id, rua, numero, complemento) values (1, 'rua 1', '10A', 'casa');
insert into endereco(id, rua, numero, complemento) values (2, 'rua 2', '10B', 'ap');
insert into endereco(id, rua, numero, complemento) values (3, 'rua 3', '10C', 'sobrado');

insert into medico(medico_crm) values ('10.101');
insert into medico(medico_crm) values ('11.111');
insert into medico(medico_crm) values ('12.120');

insert into paciente(id, numero_paciente, nome, data_nascimento, sexo, estado_civil, rg ,
telefone, id_endereco) values (1,'001', 'gege', '01-01-2001', 'M', 'Solto', '1111111111', '111111111', 1);
insert into paciente(id, numero_paciente, nome, data_nascimento, sexo, estado_civil, rg ,
telefone, id_endereco) values (2,'002', 'gaga', '02-02-2002', 'F', 'Solta', '2222222222', '222222222', 2);
insert into paciente(id, numero_paciente, nome, data_nascimento, sexo, estado_civil, rg ,
telefone, id_endereco) values (3,'003', 'gigi', '03-03-2003', 'F', 'Solte', '3333333333', '333333333', 3);

insert into exame(id, exame, data, id_paciente) values (1, 'dentario', '04-04-2004', 1);
insert into exame(id, exame, data, id_paciente) values (2, 'oftalmologico', '05-05-2005', 2);
insert into exame(id, exame, data, id_paciente) values (3, 'mental', '06-06-2006', 3);

insert into convenio(id, nome_convenio, id_paciente) values (1, 'unimed', 1);
insert into convenio(id, nome_convenio, id_paciente) values (2, 'ipê', 2);
insert into convenio(id, nome_convenio, id_paciente) values (3, 'aptil', 3);
insert into consulta(numero_consulta, id_paciente, medico_crm, id_exame) 
values (1, 1, '10.101', 1);
insert into consulta(numero_consulta, id_paciente, medico_crm, id_exame) 
values (2, 2,'11.111', 2);
insert into consulta(numero_consulta, id_paciente, medico_crm, id_exame) 
values (3, 3,'12.120', 3);

CREATE USER fulano SUPERUSER password 'fulano';
CREATE USER ciclano password 'ciclano';
--GRANT ALL PRIVILEGES ON fichamedica ALL TABLES IN SCHEMA PUBLIC_SCHEMA;
--REVOKE GRANT OPTION FOR ciclano ON INSERT, UPDATE, DELETE FROM PUBLIC_SCHEMA; 
--GRANT SELECT ALL PRIVILEGES ON SEQUENCE ALL SEQUENCES IN SCHEMA public.SCHEMA;
 