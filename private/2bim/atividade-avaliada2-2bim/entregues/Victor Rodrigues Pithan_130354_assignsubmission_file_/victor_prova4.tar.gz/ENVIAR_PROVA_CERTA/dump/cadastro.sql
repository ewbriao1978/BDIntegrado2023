DROP DATABASE IF EXISTS cadastro;

CREATE DATABASE cadastro;

\c cadastro;

CREATE TABLE funcionario (
    id SERIAL PRIMARY KEY,
    cpf CHAR(11) UNIQUE,
    nome TEXT,
    data_nasc DATE,
    nacionalidade TEXT,
    sexo CHAR(1) CHECK (sexo = 'M' OR sexo = 'F'),
    estado_civil TEXT,
    rg TEXT,
    data_admissao DATE,
    endereco TEXT,
    telefone TEXT
);

CREATE TABLE cargos (
    id SERIAL PRIMARY KEY,
    nome TEXT
);

CREATE TABLE cargo_ocupado (
    funcionario_id INTEGER REFERENCES funcionario(id),
    cargo_id INTEGER REFERENCES cargos(id),
    dt_inicio DATE,
    dt_fim DATE CHECK (dt_fim >= dt_inicio)
);

CREATE TABLE dependentes (
    id SERIAL PRIMARY KEY,
    nome TEXT,
    dt_nascimento DATE,
    funcionario_id INTEGER REFERENCES funcionario(id) ON DELETE CASCADE
);


INSERT INTO funcionario (cpf, nome, data_nasc, nacionalidade, sexo, estado_civil, rg, telefone, data_admissao, endereco) VALUES
    ('12345678910', 'Betito', '1970-03-20', 'Brasileira', 'M', 'Casado', '1234567891', '(53)999999999', '1996-01-01', 'Av. Rio grande, 1089 - Cassino');

INSERT INTO cargos(nome) VALUES
    ('Desenvolvedor Júnior'),
    ('Desenvolvedor Sênior'),
    ('Desenvolvedor Pleno');

INSERT INTO cargo_ocupado (funcionario_id, cargo_id, dt_inicio, dt_fim) VALUES
    (1,2,'1996-01-01', '2022-01-01');

INSERT INTO dependentes (nome, dt_nascimento, funcionario_id) VALUES ('Betina', '2014-07-15', 1);