DROP DATABASE IF EXISTS ficha_medica;

CREATE DATABASE ficha_medica;

\c ficha_medica;

CREATE TABLE convenio (
    id SERIAL PRIMARY KEY,
    nome TEXT
);

CREATE TABLE paciente (
    numero_paciente SERIAL PRIMARY KEY,
    nome TEXT,
    data_nasc DATE,
    sexo CHAR(1) CHECK (sexo = 'M' OR sexo = 'F'),
    convenio_id INTEGER REFERENCES convenio(id),
    estado_civil TEXT,
    rg TEXT,
    telefone TEXT,
    endereco TEXT
);

CREATE TABLE medico (
    crm CHAR(11) PRIMARY KEY, -- NÃO SEI QUANTOS SÃO COLOQUEI 11 CHARACTERES
    nome TEXT
);

CREATE TABLE consulta (
    numero_consulta SERIAL PRIMARY KEY,
    data_consulta DATE,
    numero_paciente_id INTEGER REFERENCES paciente(numero_paciente),
    medico_crm CHAR(11) REFERENCES medico(crm),
    diagnostico TEXT
);

CREATE TABLE exame (
    numero_exame SERIAL PRIMARY KEY,
    exame TEXT,
    data_exame DATE,
    numero_consulta_id INTEGER REFERENCES consulta(numero_consulta)
);

CREATE USER fulano WITH PASSWORD 'fulano' SUPERUSER;

CREATE USER ciclano WITH PASSWORD 'ciclano';
GRANT SELECT ON convenio, paciente, medico, consulta, exame TO ciclano;