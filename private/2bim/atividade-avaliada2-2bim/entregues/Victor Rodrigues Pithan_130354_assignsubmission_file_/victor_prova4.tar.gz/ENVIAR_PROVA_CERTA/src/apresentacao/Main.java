/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apresentacao;

/**
 *
 * @author Usuário
 */
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Funcionario;
import persistencia.FuncionarioDAO;

public class Main {
    public static void main(String[] args) throws SQLException {
        Funcionario denise = new Funcionario();
        denise.setCpf("12345678911");
        denise.setNome("Denise");
        denise.setEstado_civil("Solteira");
        denise.setEndereco("Rua Alfredo Ruch, 1001 - Parque Industrial");
        denise.setNacionalidade("Brasileira");
        denise.setRg("1234567893");
        denise.setTelefone("(53)888888888");
        denise.setSexo("F");
        
        new FuncionarioDAO().inserir(denise);
        System.out.println(new FuncionarioDAO().obter(2));
    }

}
