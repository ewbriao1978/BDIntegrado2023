/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.sql.*;
import java.sql.ResultSet;
import java.util.ArrayList;
import modelo.Funcionario;

/**
 *
 * @author Usuário
 */
public class FuncionarioDAO {

    public Funcionario obter(int id) throws SQLException {
        Funcionario funcionario = null;
        String sqlSelect = "SELECT * FROM funcionario WHERE id = ?;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sqlSelect);
        preparedStatement.setInt(1, id);
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            funcionario = new Funcionario();
            funcionario.setId(rs.getInt("id"));
            funcionario.setCpf(rs.getString("cpf"));
            funcionario.setNome(rs.getString("nome"));
            funcionario.setEstado_civil(rs.getString("estado_civil"));
            funcionario.setEndereco(rs.getString("endereco"));
            funcionario.setNacionalidade(rs.getString("nacionalidade"));
            funcionario.setRg(rs.getString("rg"));
            funcionario.setTelefone(rs.getString("telefone"));
            funcionario.setSexo(rs.getString("sexo"));     
        }
        rs.close();
        connection.close();
        return funcionario;
    }

    public boolean inserir(Funcionario funcionario) throws SQLException {
        boolean resultado = false;
        String sql = "INSERT INTO funcionario(cpf, nome, estado_civil, endereco, nacionalidade, rg, telefone, sexo) VALUES (?,?,?,?,?,?,?,?) RETURNING id;";
        Connection connection = new ConexaoPostgreSQL().getConexao();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, funcionario.getCpf());
        preparedStatement.setString(2, funcionario.getNome());
        preparedStatement.setString(3, funcionario.getEstado_civil());
        preparedStatement.setString(4, funcionario.getEndereco());
        preparedStatement.setString(5, funcionario.getNacionalidade());
        preparedStatement.setString(6, funcionario.getRg());
        preparedStatement.setString(7, funcionario.getTelefone());
        preparedStatement.setString(8, funcionario.getSexo());
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            funcionario.setId(rs.getInt("id"));
            resultado = true;
        }
        preparedStatement.close();
        connection.close();
        return resultado;
    }

}