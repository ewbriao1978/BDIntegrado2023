DROP DATABASE IF EXISTS ficha_medica;

CREATE DATABASE ficha_medica;

\c ficha_medica;

CREATE TABLE paciente (
		numero_paciente serial primary key NOT NULL, 
		nome text,
		data_nascimento date,
		est_civil text, 
		convenio text,
		rg character (12),
		endereco text,
		telefone text,
		sexo char(1),
		check (sexo in (‘M’, ‘F’)))
);


CREATE TABLE consultas (
	numero_consulta serial primary key, 
	data_consulta date,
	numero_exame integer references exame(id)
	crm_medico bigint NOT NULL,
	diagnostico text,
);


CREATE TABLE exames (
	numero_exame serial primary key,
	exame text,
	data_exame date;
	numero_consulta integer references consulta(id)

);


INSERT INTO pacientes (numero_paciente, nome, data_nascimento,est_civil,rg,endereco,telefone,convenio,sexo) VALUES 
INSERT INTO pacientes (1,'Fulana da Silva’,‘1976-03-20’,'casada','7257643180','Rua ABC, 123’,'32323232', 'Centro Clinico','F')
INSERT INTO pacientes (2,‘Jose das Neves’,‘1985-10-08’,'solteira', '6220261054',‘Rua NOVE, 456’,'32320000','Unimed','M')
INSERT INTO pacientes (3,‘Maria da Conceicao’,'1987-05-06','separada','1571314777','SATURNINO DE BRITO,490','30259600','IPÊ','F'),
INSERT INTO pacientes (4,‘Cleusa Maria Azevedo’,'1956-08-31','casada','0074710206','VICE ALMIRANTE ABREU, 566','32325482','Unimed','F');


INSERT INTO consultas (numero_consulta,data_consulta,crm_medico,diagnostico) VALUES
INSERT INTO consultas (14,'2022-02-01,5555','Fratura exposta'),
INSERT INTO consultas (10,'2022-04-05,6666','Enxaqueca'),
INSERT INTO consultas (15,'2022-07-09','7777','Gravidez');


INSERT INTO exames (numero_consulta, exame,data_exame) VALUES
INSERT INTO exames  (1,‘Radiografia da face’,‘2022-04-25’),
INSERT INTO exames  (2,‘Tomografia’,‘2022-05-20’),
INSERT INTO exames  (3,‘Ultrassonografia’,‘2022-05-05’);



