DROP DATABASE IF EXISTS cadastro_funcionario;

CREATE DATABASE cadastro_funcionario;

\c cadastro_funcionario;


CREATE TABLE funcionario (
		id funcionario serial primary key,
		nome text,
		cpf character (11),
		data_nascimento date,
		nacionalidade text,
		sexo character (10),
		est_civil text, 
		rg character (12),
		endereco text,
		telefone text,
		data_admissao date,
);


CREATE TABLE dependentes (
		id serial primary key,
		data_nascimento date,
		funcionario_id integer references funcionario(id)
);

	CREATE TABLE ocupacao (
		id serial primary key,
		cargo text,
		data_inicio date,
		data_fim date
);