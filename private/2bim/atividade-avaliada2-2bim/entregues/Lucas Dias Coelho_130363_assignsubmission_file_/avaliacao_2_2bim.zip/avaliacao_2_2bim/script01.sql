-- script referente a questão 1 da avaliação

drop database if exists funcionario;

create database funcionario;

\c funcionario;

create table funcionario (
    id serial primary key,
    cpf char(14) unique not null,
    rg char(10) unique not null,
    nome varchar(150) not null,
    data_nascimento date not null,
    estado_civil varchar(50) not null,
    nacionalidade varchar(100) not null,
    sexo char(1) not null check(sexo = 'M' or sexo = 'F' or sexo = 'X'),
    endereco text not null,
    data_admissao date not null 
);

create table telefone (
    id serial primary key,
    ddd char(2),
    numero varchar(20),
    id_funcionario integer references funcionario (id)
);

create table cargo (
    id serial primary key,
    nome varchar(100) not null,
    descricao text
);

create table cargo_ocupado (
    id serial primary key,
    data_inicio date not null,
    data_fim date default null,
    id_cargo integer references cargo (id),
    id_funcionario integer references funcionario (id)
);

create table dependente (
    id serial primary key,
    nome varchar(150) not null,
    data_nascimento date not null,
    id_funcionario integer references funcionario (id)
);


