-- script referente a questão 3 e 4 da avaliação

-- questao 3:
drop database if exists clinica;

create database clinica;

\c clinica;

create table paciente (
    numero_paciente serial primary key,
    nome varchar(150) not null,
    rg char(10) unique not null,
    data_nascimento date not null,
    sexo char(1) not null check(sexo = 'M' or sexo = 'F' or sexo = 'X'),
    endereco text not null,
    convenio varchar(50) default null,
    estado_civil varchar(50) not null
);

create table telefone (
    id serial primary key,
    ddd char(2),
    numero varchar(20),
    numero_paciente integer references paciente (numero_paciente)
);

create table consulta (
    numero_consulta serial primary key,
    data date not null,
    medico_crm varchar(100) unique not null,
    diagnostico text not null
);

create table exame (
    id serial primary key,
    exame text not null, 
    numero_consulta integer references consulta (numero_consulta),
    numero_paciente integer references paciente (numero_paciente)
);

\q;

-- questao 4:
drop user fulano;
drop user ciclano;

create user fulano with superuser password 'fulano';

create user ciclano with password 'ciclano';
grant select on clinica to ciclano;

select * from pg_user;