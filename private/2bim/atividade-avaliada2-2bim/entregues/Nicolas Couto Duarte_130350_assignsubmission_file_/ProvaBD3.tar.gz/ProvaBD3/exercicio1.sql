
 \c postgres
Drop database if exists exercicio1;
Create database exercicio1;

 \c exercicio1

Create table Funcionario (
    id Serial primary key,
    cpf varchar(11) unique,
    datanascimento Date NOT NULL,
    estcivil TEXT NOT NULL,
    endereço TEXT NOT NULL,
    nome TEXT NOT NULL,
    nacionalidade text not null,
    rg text not null,
    telefone text not null,
    sexo varchar(1) not null,
    dataadmissão date not null
);

Create table dependentes(
    id Serial primary key ,
    nome text not null,
    datanascimento date not null,
    Funcionario_id integer references Funcionario (id)
);

Create table cargosocupados (
id serial primary key,
Funcionario_id integer references Funcionario (id),
cargo text not null,
dtinicio date not null,
dtfim date not null,
);

insert into Funcionario (cpf,datanascimento,estcivil,endereço,nome,nacionalidade,rg,telefone,sexo,dataadmissão)values
('11111111111','04-04-2004','viuvo','rua das taquara','jabire','noruulques','213123213','213213123','M','04-04-2022');


insert into cargosocupados (Funcionario_id,cargo,dtinicio,dtfim)values
('1','descacador de montanha', '04-04-2021','04-04-2022'),
('1','descacador de construtur de navio', '04-04-2022','04-04-2022');


insert into dependentes (Funcionario_id,nome,datanascimento)values
('1','joão das neves','04-04-2002'),
('1',' irmão do joão das neves','04-04-2002');


--select * from cargosocupados where funcionario_id = 1;

--select * from Funcionario inner join cargosocupados on (funcionario.id = cargosocupados.funcionario_id);

--select * from dependentes where funcionario_id = 1;

--select * from Funcionario inner join dependentes on (funcionario.id = dependentes.funcionario_id);
