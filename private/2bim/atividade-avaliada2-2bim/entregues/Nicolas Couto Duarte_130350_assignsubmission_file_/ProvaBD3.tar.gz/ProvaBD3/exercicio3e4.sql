 \c postgres;
Drop database if exists exercicio3e4;
Create database exercicio3e4;

 \c exercicio3e4;


 create table convenio (
     id serial primary key,
     descr text
 );

Create table paciente(
    numeropaciente serial primary key,
    datanascimento Date NOT NULL,
    estcivil TEXT NOT NULL,
    endereço TEXT NOT NULL,
    nome TEXT NOT NULL,
    rg text not null,
    telefone text not null,
    sexo varchar(1) not null,
    convenio_id integer references convenio (id) 
);

Create table medico(
    crm  integer  primary key,
    nome text not null
);


Create table consultas(
    numeroconsulta Serial primary key,
    diagnostico text not null,
    data date not null,
    med_crm integer references medico (crm),
    numero_paciente integer references  paciente (numeropaciente)
);

Create table exames (
id serial primary key,
numeroconsulta integer references consultas (numeroconsulta),
exame text not null,
data date not null
);

insert into convenio  (descr)values
('o mais caro'),
('o mais barato'),
('o mais ou menos');

insert into paciente (datanascimento,estcivil,endereço,nome,rg,telefone,sexo,convenio_id)values
('04-04-2004','RSkk','logo ali','cris','12312312','123123123','M',1);

insert into medico (nome,crm)values
('João da silva filho netyo','12345');

insert into consultas (diagnostico,data,med_crm,numero_paciente )values
('vendo muito anime','04-04-2024',12345,1);

--select * from consultas where numero_paciente = 1 ;


insert into exames (numeroconsulta,exame,data)values
(1,'aquele bom','04-02-2002');

--select * from exames inner join consultas on (exames.numeroconsulta = consultas.numeroconsulta) where numero_paciente = 1

DROP USER fulano;
DROP USER ciclano;
CREATE USER fulano SUPERUSER PASSWORD 'fulano';

CREATE user ciclano PASSWORD 'ciclano';

GRANT SELECT ON  convenio TO ciclano;
GRANT SELECT ON paciente  TO ciclano;
GRANT SELECT ON  medico TO ciclano;
GRANT SELECT ON consultas  TO ciclano;
GRANT SELECT ON exames  TO ciclano;

